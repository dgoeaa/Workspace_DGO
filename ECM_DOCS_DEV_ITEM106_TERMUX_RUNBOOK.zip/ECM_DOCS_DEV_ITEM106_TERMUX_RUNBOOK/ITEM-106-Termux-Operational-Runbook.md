# ECM_DOCS_DEV ITEM-106 Operational Runbook

## Android + Termux edition

**Repository:** `https://github.com/dgoeaa/ECM_DOCS_DEV`  
**Default branch:** `claude/system-remediation-gaps-ahpmsy`  
**Purpose:** apply identification releases 62 and 63, publish the Workspace and hosted Centre, verify the real e-mail journeys, and file the owner evidence.  
**Runbook date:** 2026-11-03  

---

## 1. Read this first

### 1.0 Recommended one-command path

The safest and easiest route on Android is the resumable automation included
in this bundle:

```bash
bash ~/storage/downloads/ECM_DOCS_DEV_ITEM106_TERMUX_RUNBOOK/START-AUTOMATION.sh
```

Run the same command after any interruption. It installs missing Termux tools,
verifies and merges the repository work in order, applies and reads back the
five Flow packages, builds and publishes both sites, prepares the evidence,
opens and merges the evidence PR, and performs final verification.

The script pauses only where automation would be unsafe or impossible:
Microsoft device sign-in, FTP passwords, and the real mailbox/browser
observations. State is private under `~/.item106-automation/`; passwords are
never saved. See `AUTOMATION-README.txt` for the short operating guide. The
manual phases below remain the fallback.

### 1.1 Required final result

You are finished only when all of these are true:

- [ ] PR #89 is green, merged, and its default-branch push run is green.
- [ ] PR #90 is updated after #89, green, merged, and its push run is green.
- [ ] Releases 62 and 63 read back `UP_TO_DATE` in the tenant.
- [ ] The Workspace and hosted Centre serve the same recorded build.
- [ ] A real digest, reminder, and bulk-failure e-mail behave correctly.
- [ ] The assignee and other-person acknowledgement checks behave correctly.
- [ ] ITEM-106 is `RESOLVED` with dated evidence on the default branch.
- [ ] The evidence PR and its post-merge push run are green.
- [ ] Private build files, passwords, and temporary tenant data are cleaned up.

### 1.2 Repository status when this bundle was generated

- PR #89 merged at `7b78ea8e`; its default-branch push run passed.
- PR #90 merged after #89 at `16b33300`; its default-branch push run passed.
- No live tenant, FTP site, mailbox, or browser observation was changed while
  preparing this bundle. The launcher re-verifies repository CI before tenant
  work.

### 1.3 Ground rules

1. Run Day 0 on Monday to Thursday, preferably 09:30-16:00 WAT.
2. Run Day 1 on the next weekday, 09:00-17:00 WAT.
3. Use UTC for evidence dates: `date -u +%F`.
4. Never commit passwords, device codes, signed URLs, Safe Links wrappers,
   e-mail addresses, tenant exports, or `flows-backup-*.json`.
5. Never run two tenant tools at the same time with the same saved session.
6. Never use FTP `--delete`.
7. CI must be watched in the foreground with a timeout.
8. If a live journey fails, do not mark ITEM-106 `RESOLVED`; use
   `APPLIED_UNVERIFIED`.

### 1.4 Recommended schedule

| Time | Work |
|---|---|
| Before Day 0 | Phase 0: make PR #89 and PR #90 green and merge them |
| Day 0 morning | Phase 1: sign in; Phase 2: apply releases 62 and 63 |
| Day 0 midday | Phase 3: build and publish Centre, then Workspace |
| Day 0 afternoon | Phase 4A: create the test records, tasks, reminder, and bulk failure |
| Day 1 | Phase 4B: run the sweep, inspect the e-mails, and clean test data |
| Day 1 after verification | Phase 5: file evidence, update ITEM-106, open and merge evidence PR |
| After the evidence push run | Phase 6: final read-only verification and private-file cleanup |

---

# Phase 0 - Prepare Termux and merge the repository work

## 0.1 Install the phone tools

```bash
pkg update && pkg upgrade -y
pkg install -y git nodejs-lts gh zip unzip lftp curl nano
termux-setup-storage
termux-wake-lock
node -v
```

Node must be version 22 or later.

Check that Microsoft sign-in can resolve from the phone:

```bash
curl -sS -o /dev/null -w '%{http_code}\n' \
  https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration
```

Expect `200`. Stop if it does not.

## 0.2 Sign in to GitHub

```bash
gh auth login
gh auth setup-git
gh auth status
git config --global user.name "YOUR NAME"
git config --global user.email "YOUR GITHUB NOREPLY EMAIL"
```

Use your GitHub no-reply address if you do not want your personal address in
commits.

## 0.3 Clone or refresh the repository

New clone:

```bash
cd ~
git clone https://github.com/dgoeaa/ECM_DOCS_DEV.git
cd ~/ECM_DOCS_DEV
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
```

Existing clone:

```bash
cd ~/ECM_DOCS_DEV
git status --short
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
```

Do not continue if `git status --short` shows an unexplained local change.

## 0.4 Add bounded CI watchers

```bash
cat >> ~/.bashrc <<'EOF'
watchpr(){
  sleep 30
  for i in $(seq 1 14); do
    timeout 540 gh pr checks "$1" -R dgoeaa/ECM_DOCS_DEV --watch --interval 30
    rc=$?
    [ $rc -ne 124 ] && break
    echo "still running after $((i*9)) min"
  done
  echo "exit $rc"
  return $rc
}
watchrun(){
  for i in $(seq 1 14); do
    timeout 540 gh run watch "$1" -R dgoeaa/ECM_DOCS_DEV \
      --exit-status --interval 30 --compact
    rc=$?
    [ $rc -ne 124 ] && break
    echo "still running after $((i*9)) min"
  done
  echo "exit $rc"
  return $rc
}
EOF
source ~/.bashrc
```

Exit meanings:

- `0`: green.
- `1`: failed.
- `124`: still running when that nine-minute round ended; run the watcher again.

## 0.5 Re-check PR #89 before doing anything else

```bash
cd ~/ECM_DOCS_DEV
git fetch -q origin
gh pr view 89 -R dgoeaa/ECM_DOCS_DEV \
  --json state,isDraft,mergeable,mergeStateStatus,headRefOid \
  -q '"state=\(.state) draft=\(.isDraft) github=\(.mergeable)/\(.mergeStateStatus) head=\(.headRefOid[0:8])"'

git merge-tree --write-tree \
  origin/claude/system-remediation-gaps-ahpmsy \
  origin/copilot/repair-acknowledgement-deeplinks >/dev/null \
  && echo CLEAN || echo CONFLICTS

gh pr checks 89 -R dgoeaa/ECM_DOCS_DEV
```

Proceed to merge only if:

- the PR is open and not a draft;
- `merge-tree` prints `CLEAN`;
- Full gate, Chromium, Firefox, WebKit, Link check, Module graph, and Secret
  scan all pass.

### If the runtime-budget failure is still present

Create and post this agent request:

```bash
cat > ~/fix-pr89.md <<'EOF'
@copilot

Update PR #89 in dgoeaa/ECM_DOCS_DEV. Do not merge it and do not touch the live tenant.

The branch is merge-clean, but CI is red. In Chromium, all 508 Playwright tests
passed, then test:uxruntime failed with:

  core/deeplink-parse.js: compressed growth exceeds 10%

Reduce or restructure that file so the compressed-growth gate passes without
changing the repaired deeplink behaviour. Preserve releases 62 and 63 and their
five flow packages. Keep official and legacy task references open-only unless an
explicit acknowledgement link is used. Run the relevant runtime-budget check,
the full gate, all three browser smoke jobs, link check, module graph and secret
scan, then push the fix. Update the PR description if necessary.
EOF

gh pr comment 89 -R dgoeaa/ECM_DOCS_DEV --body-file ~/fix-pr89.md
watchpr 89
```

If `watchpr 89` exits 1:

```bash
gh pr checks 89 -R dgoeaa/ECM_DOCS_DEV
```

Open the failed job link, or after the run finishes:

```bash
gh run view RUN_ID -R dgoeaa/ECM_DOCS_DEV --log-failed | tail -80
```

## 0.6 Merge PR #89 and watch the push run

Only after every check is green:

```bash
gh pr merge 89 -R dgoeaa/ECM_DOCS_DEV --merge
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
H=$(git rev-parse HEAD)

RUN=
for i in 1 2 3 4 5 6; do
  RUN=$(gh run list -R dgoeaa/ECM_DOCS_DEV --workflow ci.yml \
    --commit "$H" --event push --limit 1 --json databaseId \
    -q '.[0].databaseId')
  [ -n "$RUN" ] && break
  sleep 20
done

echo "push run: ${RUN:-not found}"
[ -n "$RUN" ] && watchrun "$RUN"
```

Do not continue if the push run is red.

## 0.7 Update and merge PR #90 after PR #89

PR #90 is now the governance follow-up. Do not close it as a duplicate.

```bash
cat > ~/update-pr90.md <<'EOF'
@copilot

Update PR #90 after PR #89 has merged.

Merge the current default branch into the PR #90 branch with a merge commit; do
not rebase or force-push. Keep PR #90 governance-only relative to the merged
default branch: retain its dated ENDPOINT_FLOW_REQUIREMENTS reconciliation and
governed projections, but no alternate acknowledgement runtime and no tenant
claim. Regenerate all affected outputs from their generators, run the full gate
and all required CI jobs, and push. Do not merge and do not touch the tenant.
EOF

gh pr comment 90 -R dgoeaa/ECM_DOCS_DEV --body-file ~/update-pr90.md
watchpr 90
```

When every PR #90 check is green:

```bash
gh pr merge 90 -R dgoeaa/ECM_DOCS_DEV --merge
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
H=$(git rev-parse HEAD)

RUN=
for i in 1 2 3 4 5 6; do
  RUN=$(gh run list -R dgoeaa/ECM_DOCS_DEV --workflow ci.yml \
    --commit "$H" --event push --limit 1 --json databaseId \
    -q '.[0].databaseId')
  [ -n "$RUN" ] && break
  sleep 20
done

[ -n "$RUN" ] && watchrun "$RUN"
```

## 0.8 Install dependencies and run the two local checks

```bash
cd ~/ECM_DOCS_DEV
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 PUPPETEER_SKIP_DOWNLOAD=1 \
  npm ci --ignore-scripts
npm run -s test:deeplinks
npm run -s test:flowsupdate
```

Check ITEM-106:

```bash
node -p 'const i=require("./docs/deployment/PRODUCTION_READINESS_REGISTER.json").items.find(x=>x.id==="ITEM-106");[i.status,...i.steps].join("\n")'
```

Before tenant work, expect:

- `SPECIFIED_NOT_APPLIED`;
- S1 marked done;
- S2 and S3 marked `(owner)`.

---

# Phase 1 - Sign in to the live tenant

## 1.1 Start Day 0

```bash
echo "D0=$(date -u +%F)" > ~/item106.env
cd ~/ECM_DOCS_DEV
```

## 1.2 Set up and load the saved agent session

First use:

```bash
npm run agent:access -- setup
source ~/NITDA-Folio-Agent/env.sh
npm run agent:access -- signin flow
```

Termux prints a Microsoft device-login address and a short code:

1. Long-press the code and copy it.
2. Open the address in Chrome.
3. Enter the code.
4. Sign in with the flow-owner account.
5. Return to Termux.

Every later Termux session:

```bash
source ~/NITDA-Folio-Agent/env.sh
```

Verify the session:

```bash
npm run agent:access -- status --live --resource flow
```

Expect `"liveVerified": true` and HTTP `200`.

---

# Phase 2 - Apply identification releases 62 and 63

## 2.1 Know the five flows

| Release | Flow | Full flow ID |
|---|---|---|
| 62 | DYNAMIC_ACTIONS | `31c0aaf0-ddbb-478c-9a98-bc013265c4c7` |
| 62 | FETCH_ALL_BOOTSTRAP | `b79e6707-df4d-4ae7-8a65-738aa45e9a73` |
| 63 | BULK_OPS | `5aab9e61-ab9f-4af1-9f2b-eaba23a1bf06` |
| 63 | AUTO_SCHEDULED_SWEEP | `8c19b45c-4174-4d2f-9429-ffd08dd1a5ae` |
| 63 | Scan Processing | `197527c8-e76c-4f7d-81b8-3cb5c88b1c6c` |

`flows:update --only` accepts the eight-character prefixes. `flows:inspect
--flow` requires the full GUID.

## 2.2 Run the pre-apply check

```bash
cd ~/ECM_DOCS_DEV
source ~/NITDA-Folio-Agent/env.sh
mkdir -p ~/item106-flows

npm run -s flows:update -- check --out ~/item106-flows
echo "exit $?"
```

Expected initial result:

- the five rows above: `WILL_UPDATE`;
- the other current packages: `UP_TO_DATE`;
- exit `1`, because writes are available.

Stop if any row is `HELD`, `BLOCKED`, `FAILED`, or `CHANGED`.

## 2.3 Apply release 62

```bash
npm run -s flows:update -- apply \
  --only 31c0aaf0,b79e6707 \
  --out ~/item106-flows
```

Review the two-flow plan, then answer `y`.

Expect:

- backup written before the first write;
- each flow written and read back;
- `Done`;
- a config-current or rebuild-suggested verdict.

## 2.4 Apply release 63

```bash
npm run -s flows:update -- apply \
  --only 5aab9e61,8c19b45c,197527c8 \
  --out ~/item106-flows
```

Review the three-flow plan, then answer `y`.

Applying a package does not change whether a flow is On or Off.

## 2.5 Read all five back

```bash
npm run -s flows:update -- check \
  --only 31c0aaf0,b79e6707,5aab9e61,8c19b45c,197527c8 \
  --out ~/item106-flows
echo "exit $?"
```

Expect five `UP_TO_DATE` rows and exit `0`.

```bash
echo "DA=$(date -u +%F)" >> ~/item106.env
```

Do not delete `~/item106-flows`; it contains reports and private rollback
backups.

## 2.6 Status meanings

| Status | Meaning and action |
|---|---|
| `UP_TO_DATE` | No action |
| `WILL_UPDATE` | Review before apply |
| `APPLIED` | Run the package test/readback |
| `HELD` | A prerequisite is missing; identify it fully |
| `BLOCKED` | Follow the printed reason |
| `FAILED` | Restoration was attempted; reconcile before another write |
| `CHANGED` | A concurrent edit occurred; do not retry blindly |
| `NOT_RUN` | An earlier failure stopped the run |

## 2.7 Rollback if an apply genuinely failed

Use the exact backup path printed by the failed apply:

```bash
npm run -s flows:update -- restore \
  ~/item106-flows/flows-backup-EXACT-TIMESTAMP.json
```

Restore has no confirmation prompt. Do not guess the backup file.

## 2.8 Manual-paste fallback

Use this only if the automated apply cannot be used:

1. Open
   `docs/folio-Master-Flows-and-Endpoints/packages/identification-phase4/README.md`.
2. Open each flow in Power Automate.
3. Delete its named root scope.
4. Choose **Paste an action**.
5. Paste the matching `.paste.json` package.
6. Keep required Initialize variable actions.
7. Repair any **Invalid connection** warning.
8. Save and run the final `flows:update check`.

DYNAMIC_ACTIONS has about 483 steps. Use a desktop browser or Chrome's Desktop
site mode; a phone-only editor is risky.

---

# Phase 3 - Build and publish the Workspace and Centre

## 3.1 Build from the merged default branch

```bash
cd ~/ECM_DOCS_DEV
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
source ~/NITDA-Folio-Agent/env.sh
npm run -s config:rebuild
```

Expected messages include:

- `Built v<version> (commit <8>) in <folder>`;
- a Workspace ZIP and Centre ZIP;
- the Workspace may say `NO mailer.html (pass --mailer)`; that is acceptable
  for this publication;
- the config-build ledger was updated.

Even if the command says no address changed, publish this build because the
application code changed.

## 3.2 Save the build identity

```bash
LEDGER=docs/folio-Master-Flows-and-Endpoints/registers/config-build-ledger.json
VER=$(node -p "require('./$LEDGER').version")
COMMIT=$(node -p "require('./$LEDGER').commit")
OUT=$(ls -1dt ~/folio-config-build/*/ | head -1)

printf 'LEDGER=%s\nVER=%s\nCOMMIT=%s\nOUT=%s\n' \
  "$LEDGER" "$VER" "$COMMIT" "$OUT"

cat >> ~/item106.env <<EOF
LEDGER=$LEDGER
VER=$VER
COMMIT=$COMMIT
OUT=$OUT
EOF
```

The folder contains signed live addresses. Keep it private.

## 3.3 Prepare FTP safely

Get the FTP username and target folder from the InfinityFree client area's
**FTP Details**. The host is `ftpupload.net`.

```bash
FTPSET="set ftp:ssl-force true; set ftp:ssl-protect-data true; \
set ftp:ssl-protect-list true; set ssl:ca-file $PREFIX/etc/tls/cert.pem"
ftpdo(){
  lftp --env-password -u "$1" \
    -e "$FTPSET; $2; bye" ftpupload.net
}
```

For each account:

```bash
read -rs LFTP_PASSWORD
export LFTP_PASSWORD
```

The password is not displayed. Do not put it in `item106.env`.

The target may be `/htdocs` or `/<domain>/htdocs`. Inspect first:

```bash
ftpdo YOUR_FTP_USER "cls -a /"
```

## 3.4 Publish the hosted Centre first

Set the real values:

```bash
CAC_USER='if0_REPLACE'
CAC_DIR='/htdocs'
mkdir -p ~/site-backup/centre-before
```

Read the current build:

```bash
ftpdo "$CAC_USER" "cat $CAC_DIR/BUILD-ID.json"
```

Back it up:

```bash
ftpdo "$CAC_USER" \
  "mirror --no-perms $CAC_DIR/ $HOME/site-backup/centre-before/"
```

Upload:

```bash
ftpdo "$CAC_USER" \
  "mirror -R --no-perms --transfer-all --verbose ${OUT}centre/ $CAC_DIR/"
```

Never add `--delete`.

In Chrome private mode, open:

`https://folio-cac.page.gd/BUILD-ID.json?x=1`

Confirm:

- `package` is `FOLIO-CENTRE`;
- `version` is `$VER`;
- `commit` is `$COMMIT`.

Then sign in to the Centre with an authorized account and confirm a governance
list can be read.

## 3.5 Publish the Workspace second

If it uses another FTP account, re-enter its password:

```bash
unset LFTP_PASSWORD
read -rs LFTP_PASSWORD
export LFTP_PASSWORD
```

Set the real values:

```bash
WS_USER='if0_REPLACE'
WS_DIR='/htdocs'
mkdir -p ~/site-backup/workspace-before
```

Stop if `WS_USER` and `WS_DIR` are both identical to `CAC_USER` and `CAC_DIR`;
that would publish both packages into the same site root.

Read and back up:

```bash
ftpdo "$WS_USER" "cat $WS_DIR/BUILD-ID.json"
ftpdo "$WS_USER" \
  "mirror --no-perms $WS_DIR/ $HOME/site-backup/workspace-before/"
```

Upload:

```bash
ftpdo "$WS_USER" \
  "mirror -R --no-perms --transfer-all --verbose ${OUT}workspace/ $WS_DIR/"
```

In Chrome private mode, open:

`https://folio-platform.page.gd/BUILD-ID.json?x=1`

Confirm:

- `package` is `FOLIO-WORKSPACE`;
- `version` is `$VER`;
- `commit` is `$COMMIT`;
- the Workspace account menu shows the same build.

Do not publish the Portal for ITEM-106.

## 3.6 File Manager alternative

If FTP is unusable:

```bash
mkdir -p /storage/emulated/0/Folio_Production_Packages
cp "$OUT/FOLIO-CENTRE-v$VER-upload-to-site-root.zip" \
  /storage/emulated/0/Folio_Production_Packages/
cp "$OUT/FOLIO-WORKSPACE-v$VER-upload-to-site-root.zip" \
  /storage/emulated/0/Folio_Production_Packages/
```

Upload and extract each ZIP into that site's `htdocs`. Do not extract one site
over the other. Re-check both `BUILD-ID.json` files.

## 3.7 Rollback

Only if a published site is broken:

```bash
ftpdo "$CAC_USER" \
  "mirror -R --no-perms --transfer-all $HOME/site-backup/centre-before/ $CAC_DIR/"

ftpdo "$WS_USER" \
  "mirror -R --no-perms --transfer-all $HOME/site-backup/workspace-before/ $WS_DIR/"
```

`--transfer-all` is essential; without it, older or same-size backup files may
be skipped. Because the safe upload deliberately omits `--delete`, restoring
the backup replaces prior files but does not remove brand-new files introduced
by the failed upload; remove only those confirmed additions manually.

---

# Phase 4 - Verify real e-mail and acknowledgement journeys

## 4.1 Read Flow Configuration before creating data

In the SharePoint **Flow Configuration** list, record the current values without
copying private addresses into Git:

- `NOTIFY_ENABLED`;
- `NOTIFY_WORKING_HOURS_ONLY`;
- `NOTIFY_SWEEP_RECIPIENTS`;
- `NOTIFY_OPS_TO`;
- the identity-map site/list values needed for cleanup.

The sweep normally runs weekdays at 08:45 WAT. A date-only reminder becomes due
at 08:00 WAT. Digest throttling is a rolling 24 hours per recipient.

## 4.2 Decide how to handle the sweep

Choose one:

| Option | Action |
|---|---|
| A | Turn it on before 08:45 WAT and leave it on |
| B - recommended while the old stop reason is unknown | Day 1: Turn on -> Run -> wait for Succeeded -> Turn off |
| C | As B, but in shadow mode; restore the prior config afterwards |

Record the decision. Do not silently leave a previously stopped production flow
running.

## 4.3 Create four Day 0 test records

Create separate records named:

- `ZTEST-A`;
- `ZTEST-B`;
- `ZTEST-C`;
- `ZTEST-BULK`.

Workspace path:

1. **Register**.
2. Inbox -> **Register a document**.
3. **Internal** / Log New Memo.
4. Accept **Confirm new correspondence**.
5. Accept **Confirm DYNAMIC_ACTIONS execution**.
6. Record each resulting reference.

## 4.4 Create tasks A, B and C

| Task | Assigned to | Ack due | Task due | Action |
|---|---|---|---|---|
| A | Owner | Day 0 | Day 0 + 7 days | Do not click its assignment link; set reminder for Day 1 |
| B | Owner | Day 0 | Day 0 | Acknowledge from its assignment e-mail; verify in a fresh private tab |
| C | Colleague; owner copied | Day 0 + 14 | Day 0 + 14 | Owner opens copied link; expect rejection and no saved receipt |

For A, an orchestrator uses **Remind on = Day 1**, then **Set reminder**.

For C, expect wording similar to:

`Not acknowledged: this task is assigned to someone else.`

## 4.5 Produce one genuine bulk-failure e-mail

1. In Inbox, tick `ZTEST-BULK`.
2. Choose **Assign selected (1)**.
3. Fill the form but do not submit.
4. In another tab, delete that record's Portal Registry row.
5. Return to the still-open bulk form without refreshing.
6. Press **Check and apply**.

Expect:

- subject `Bulk assignment: 1 of 1 not completed`;
- one failed row;
- the e-mail button opens `index.html#/inbox`;
- a `bulk-failure` Portal Outbox Receipt.

If the UI removes the row before submission, create a fresh ZTEST record and
repeat.

## 4.6 Day 1: run the sweep

```bash
echo "D1=$(date -u +%F)" >> ~/item106.env
```

If using option B:

1. Open Power Automate in Chrome Desktop site mode.
2. Open `AUTO_SCHEDULED_SWEEP`.
3. Turn it on.
4. Choose **Run**.
5. Wait for `Succeeded`.
6. Turn it off again.

## 4.7 Check messages in this exact order

Do acknowledgement last.

1. **Reminder:** open its task reference. It must open A and must not
   acknowledge it.
2. **Digest task reference:** open A. It must open A and must not acknowledge
   it.
3. **Digest Acknowledge receipt:** long-press/copy its URL. `items=` must contain
   A only, not B or C.
4. **Open my tasks:** must open `#/tasks`.
5. **Other-person link:** C must remain unacknowledged.
6. Only after every check is correct, press the digest's **Acknowledge receipt**
   button for A.

Expected link shapes:

```text
Digest task:
index.html?item=<SharePoint item ID>&intent=open&source=digest

Digest acknowledge:
index.html?items=<comma-separated IDs>&source=digest

Open my tasks:
index.html#/tasks

Reminder:
index.html?ref=<TASK reference>&intent=open&source=reminder

Bulk failure:
index.html#/inbox
```

If Outlook wraps the link in Safe Links, decode the outer `url` parameter:

```bash
node -e 'const u=new URL(process.argv[1]); console.log(u.searchParams.get("url")||u.href)' \
  'PASTE_THE_LINK'
```

Do not put the wrapper or a signed URL in evidence.

## 4.8 Inspect the flow runs

```bash
cd ~/ECM_DOCS_DEV
source ~/NITDA-Folio-Agent/env.sh
source ~/item106.env
mkdir -p ~/item106-evidence

npm run -s flows:inspect -- \
  --since "$D0" \
  --flow 8c19b45c-4174-4d2f-9429-ffd08dd1a5ae \
  --out ~/runs.json

node -e 'for(const r of require(process.env.HOME+"/runs.json").runs) console.log(r.runId,r.startTime,r.runStatus)'
```

Choose the successful Day 1 run:

```bash
RUNID='REPLACE_WITH_SWEEP_RUN_ID'
npm run -s flows:inspect -- \
  --run "$RUNID" \
  --flow 8c19b45c-4174-4d2f-9429-ffd08dd1a5ae \
  --out ~/item106-evidence/$D1-inspection-sweep.json
```

Optional bulk inspection:

```bash
BULKRUN='REPLACE_WITH_BULK_RUN_ID'
npm run -s flows:inspect -- \
  --run "$BULKRUN" \
  --flow 5aab9e61-ab9f-4af1-9f2b-eaba23a1bf06 \
  --out ~/item106-evidence/$D0-inspection-bulk-failure.json
```

Never commit `~/runs.json`.

## 4.9 Clean the test data

Delete the ZTEST data from:

- Portal Registry;
- Global Tracking Queue;
- DGO_TaskReminders;
- DGO DIGITAL OPS mirror rows;
- DGO_IdentityMap locator rows.

Keep:

- Portal Outbox Receipts;
- audit rows.

Restore any changed Flow Configuration values. Record the references and cleanup
date, but not personal addresses.

---

# Phase 5 - File evidence and close ITEM-106

## 5.1 Locate this downloaded bundle

If you extracted it as instructed:

```bash
export BUNDLE=~/ECM_DOCS_DEV_ITEM106_TERMUX_RUNBOOK
test -f "$BUNDLE/scripts/item106.mjs" && echo "bundle ready"
```

## 5.2 Create the evidence branch while keeping the build-ledger change

```bash
cd ~/ECM_DOCS_DEV
source ~/item106.env
git stash push -m item106-config-build
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
git stash pop
git checkout -b owner/item106-evidence
git status --short
```

Normally the config-build ledger is the only initial modification.

If `stash pop` conflicts on the ledger, keep the stashed owner build:

```bash
git checkout --theirs -- "$LEDGER"
git reset -q
git stash drop
```

## 5.3 Record the flows reports, oldest first

```bash
: > ~/item106-recorded.txt
for f in $(ls -1tr \
  ~/item106-flows/flows-check-*.json \
  ~/item106-flows/flows-apply-*.json); do
  npm run -s flows:update -- record "$f" | tee -a ~/item106-recorded.txt
done

grep '^Evidence:' ~/item106-recorded.txt
```

Use every `Evidence:` path that the command prints. A duplicate report exits 2
and says it was already recorded; skip that report.

## 5.4 Copy the run inspections

```bash
EV=docs/folio-Master-Flows-and-Endpoints/evidence
cp ~/item106-evidence/*.json "$EV/"
```

## 5.5 Create and edit the owner-observations file

```bash
source ~/item106.env
EV=docs/folio-Master-Flows-and-Endpoints/evidence
OBS=$EV/$D1-item106-owner-observations.json
source "$BUNDLE/templates/owner-observations-template.sh"
nano "$OBS"
```

Replace every `REPLACE`.

- Use record/task references, run IDs, and Outbox Receipt item IDs.
- Do not include an e-mail address.
- Do not include signed URL parameters.
- Do not include a Safe Links wrapper.
- Change `"pass": "REPLACE"` to `"pass": true` only for a journey that behaved
  exactly as described.
- If a journey failed, describe the real result and use `false`.

Nano:

- Ctrl+W: search for `REPLACE`;
- Ctrl+O, Enter: save;
- Ctrl+X: exit.

Install and run the checker:

```bash
cp "$BUNDLE/scripts/obscheck.mjs" ~/obscheck.mjs
node ~/obscheck.mjs "$OBS"
```

To resolve ITEM-106, expect:

`Observations OK: 5 journeys, all passed.`

## 5.6 Install and verify the ITEM-106 helper

```bash
cp "$BUNDLE/scripts/item106.mjs" ~/item106.mjs
node --check ~/item106.mjs
sha256sum ~/item106.mjs | cut -c1-16
```

Expect:

`159e264fdaae8ec5`

The helper was re-tested against PR #90's synchronized register head and marked
S2/S3 done correctly.

## 5.7 Build the helper's evidence arguments

```bash
PAIRS=()
while read -r _ f; do
  case "$f" in
    *-flows-check*)
      what="flows:update check: live state of the release 62 and 63 flows when read"
      ;;
    *-flows-apply*)
      what="flows:update apply: release 62 or 63 packages written and read back"
      ;;
    *)
      echo "unexpected: $f"
      continue
      ;;
  esac
  PAIRS+=("$f::$what")
done < <(grep '^Evidence:' ~/item106-recorded.txt)

[ -f "$EV/$D1-inspection-sweep.json" ] && \
  PAIRS+=("$EV/$D1-inspection-sweep.json::flows:inspect of the AUTO_SCHEDULED_SWEEP run that sent the digest and reminder")

[ -f "$EV/$D0-inspection-bulk-failure.json" ] && \
  PAIRS+=("$EV/$D0-inspection-bulk-failure.json::flows:inspect of the BULK_OPS run that sent the bulk-failure e-mail")

PAIRS+=("$OBS::the owner's observations of the five e-mail and link journeys")
PAIRS+=("$LEDGER::build $VER: the Workspace and Centre published from one commit")

printf '%s\n' "${PAIRS[@]}"
echo "${#PAIRS[@]} evidence arguments"
```

Expect approximately 7-8 arguments and no `unexpected:` line.

## 5.8 Mark ITEM-106 RESOLVED

Only if the observations checker passed:

```bash
node ~/item106.mjs RESOLVED \
  "Nothing open on this item: releases 62 and 63 read back UP_TO_DATE on $DA, the Workspace and hosted Centre were published from build $VER, and the digest, reminder and bulk-failure journeys were observed as Part 5.2 states." \
  "ITEM-106 resolved on the owner's evidence: releases 62 and 63 applied and read back, build $VER published to the Workspace and hosted Centre, and the five journeys observed between $D0 and $D1." \
  "${PAIRS[@]}"
```

Verify:

```bash
node -p 'const i=require("./docs/deployment/PRODUCTION_READINESS_REGISTER.json").items.find(x=>x.id==="ITEM-106");[i.status,...i.steps].join("\n")'
```

Expect `RESOLVED`, with S2 and S3 marked done.

### If any journey failed

Do not use `RESOLVED`. Use:

```bash
node ~/item106.mjs APPLIED_UNVERIFIED \
  "Releases 62 and 63 read back UP_TO_DATE on $DA and build $VER is published to the Workspace and hosted Centre. Still to observe: WRITE THE REMAINING JOURNEY OR FAILURE IN WORDS." \
  "ITEM-106 applied on the owner's evidence: releases 62 and 63 read back and build $VER published; live journeys remain to be completed." \
  "${PAIRS[@]}"
```

Do not write counts such as `1 of 3` in `whyOpen`; the helper rejects them.

## 5.9 Regenerate derived documents

```bash
PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 PUPPETEER_SKIP_DOWNLOAD=1 \
  npm ci --ignore-scripts

for s in flowreq plan disposition outstanding platform \
  flows:regenerate docsite docs:catalogue; do
  echo "== $s"
  npm run -s "$s" > ~/gen-${s//:/_}.log 2>&1 || {
    echo "FAILED: $s -> ~/gen-${s//:/_}.log"
    break
  }
done
```

Expect eight headings and no `FAILED`.

## 5.10 Run the targeted gate with fifteen-minute limits

```bash
fails=()
for s in \
  test:secrets test:readiness test:plan test:disposition \
  test:outstanding test:platform test:console test:flowreq \
  test:closure test:docmigration test:docsite test:catalogue \
  test:runbook test:governancerunbook test:links test:deeplinks \
  test:ackactor test:idrelease test:idphase3 test:idphase4 \
  test:governancewalkthrough test:estateregister test:productiontrace \
  test:flowsupdate test:configbuild test:endpointregister \
  test:commissioningauthority test:imports; do

  log=~/gate-${s//:/_}.log
  if timeout 900 npm run -s "$s" > "$log" 2>&1; then
    echo "ok    $s"
  else
    rc=$?
    echo "FAIL  $s (exit $rc) -> $log"
    fails+=("$s")
  fi
done

node scripts/run-test-gate.mjs --check
echo "failed: ${fails[*]:-none}"
```

Expect:

- 28 `ok` lines;
- `Test inventory: ... no undeclared omissions.`;
- `failed: none`.

Android does not support the repository's full Playwright run. The PR CI is the
arbiter for browser tests.

If a log says `stale - run: npm run X`, run X, then:

```bash
npm run -s docsite
npm run -s docs:catalogue
```

Re-run the failed checks.

## 5.11 Review, commit, and push

```bash
git add -A docs tools
git status --short
git status --short | grep -vE '^(A|M|R|D) ' || echo "all staged"
```

Expect roughly 25-30 paths. Stop if anything outside `docs/` or `tools/` is
unexpectedly staged.

```bash
git commit \
  -m "ITEM-106: owner evidence for releases 62 and 63 and build $VER" \
  -m "Record flow apply/readback, host publication, run inspections and the owner's observed journeys; update readiness and regenerate governed outputs."

git push -u origin owner/item106-evidence
```

## 5.12 Open and merge the evidence PR

```bash
cp "$BUNDLE/templates/pr-body-template.md" ~/pr-body.md
nano ~/pr-body.md
```

Replace every `REPLACE`, remove instructions that do not match what happened,
and keep all private addresses/credentials out.

```bash
URL=$(gh pr create -R dgoeaa/ECM_DOCS_DEV \
  --base claude/system-remediation-gaps-ahpmsy \
  --head owner/item106-evidence \
  --title "ITEM-106: owner evidence (releases 62 and 63, build $VER)" \
  --body-file ~/pr-body.md)

echo "$URL"
PR=${URL##*/}
echo "PR=$PR" >> ~/item106.env
watchpr "$PR"
```

Merge only after all checks are green:

```bash
gh pr merge "$PR" -R dgoeaa/ECM_DOCS_DEV --merge --delete-branch
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
H=$(git rev-parse HEAD)

RUN=
for i in 1 2 3 4 5 6; do
  RUN=$(gh run list -R dgoeaa/ECM_DOCS_DEV --workflow ci.yml \
    --commit "$H" --event push --limit 1 --json databaseId \
    -q '.[0].databaseId')
  [ -n "$RUN" ] && break
  sleep 20
done

[ -n "$RUN" ] && watchrun "$RUN"
```

If the base moved and pins drifted:

1. Merge the current base into `owner/item106-evidence`.
2. Resolve evidence/register files by keeping both valid histories.
3. Re-run steps 5.7-5.10.
4. Commit the new pin/regeneration and push again.

---

# Phase 6 - Final operational verification

Run this only after the evidence PR's default-branch push run is green.

## 6.1 Pull and sign in

```bash
cd ~/ECM_DOCS_DEV
git checkout claude/system-remediation-gaps-ahpmsy
git pull --ff-only
source ~/item106.env
source ~/NITDA-Folio-Agent/env.sh
npm run agent:access -- status --live --resource flow || \
  npm run agent:access -- signin flow
```

## 6.2 Check ITEM-106

```bash
node -p 'const i=require("./docs/deployment/PRODUCTION_READINESS_REGISTER.json").items.find(x=>x.id==="ITEM-106");[i.status,i.whyOpen,...i.steps].join("\n")'
```

Expect `RESOLVED`, nothing open, and S1-S3 all done.

## 6.3 Check the five flows one final time

```bash
npm run -s flows:update -- check \
  --only 31c0aaf0,b79e6707,5aab9e61,8c19b45c,197527c8 \
  --out ~/item106-final
echo "exit $?"
```

Expect five `UP_TO_DATE` rows and exit `0`. Do not record this confirmation
report.

## 6.4 Check configuration drift

```bash
npm run -s config:drift
echo "exit $?"
```

Expect exit `0`. Exit `3` means addresses changed after the build; rebuild and
republish before declaring completion.

## 6.5 Re-check both deployed builds

```bash
node -e 'const l=require("./docs/folio-Master-Flows-and-Endpoints/registers/config-build-ledger.json");console.log("ledger",l.version,l.commit);for(const k of ["workspace","centre"]){const b=l.builds[k];console.log(k,b.codeFingerprint,b.configDigest)}'
echo "expected $VER $COMMIT"
```

Open in Chrome:

- `https://folio-platform.page.gd/BUILD-ID.json?x=1`
- `https://folio-cac.page.gd/BUILD-ID.json?x=1`

Each must match the ledger's version, commit, code fingerprint, and config
digest. The package names must be `FOLIO-WORKSPACE` and `FOLIO-CENTRE`.

## 6.6 Confirm the operational state

- The sweep is left in the state you deliberately chose.
- Flow Configuration values are restored.
- ZTEST records/tasks/reminder/mirror/locator rows are gone.
- Outbox receipts and audit rows remain.
- The Workspace account menu shows build `$VER`.

## 6.7 Optional host reachability workflow

```bash
gh workflow run published-hosts.yml -R dgoeaa/ECM_DOCS_DEV
sleep 15
RUN=$(gh run list -R dgoeaa/ECM_DOCS_DEV \
  --workflow published-hosts.yml --event workflow_dispatch \
  --limit 1 --json databaseId -q '.[0].databaseId')
watchrun "$RUN"
```

This checks published reachability, not the Centre's build identity. Step 6.5
remains required.

## 6.8 Delete private temporary files

```bash
source ~/item106.env
rm -rf "$OUT" ~/item106-evidence ~/item106-final
rm -f ~/runs.json ~/gate-*.log ~/gen-*.log
rm -f ~/item106-recorded.txt ~/pr-body.md ~/fix-pr89.md ~/update-pr90.md
rm -f /storage/emulated/0/Folio_Production_Packages/FOLIO-*-v"$VER"-*.zip
unset LFTP_PASSWORD
npm run agent:access -- signout flow
termux-wake-unlock
```

Keep `~/item106-flows` and `~/site-backup` for about one week because they
contain Flow and FTP rollback backups. Then:

```bash
rm -rf ~/item106-flows ~/site-backup
rm -f ~/item106.mjs ~/obscheck.mjs ~/item106.env
```

---

# Troubleshooting

| Problem | Action |
|---|---|
| PR #89 or #90 is red | Do not merge. Read `gh pr checks <N>` and the failed log |
| `core/deeplink-parse.js: compressed growth exceeds 10%` | Have the PR agent reduce/restructure it without changing behavior or packages |
| `merge-tree` prints `CONFLICTS` | Ask the PR agent to merge the current default branch; no rebase/force-push |
| `watchpr`/`watchrun` exits 124 | It is still running; run the watcher again |
| `flows:update record` exits 2 | Duplicate, wrong environment, or not a valid report; read its message |
| `flows:inspect` finds no flow | Use the full GUID, not the eight-character prefix |
| 401/403 | Re-run `source ~/NITDA-Folio-Agent/env.sh` and `signin flow` |
| `HELD` | Identify the full missing prerequisite before proceeding |
| `CHANGED` | A concurrent edit happened; inspect it rather than retrying blindly |
| lftp certificate error | Set `FTPSET="set ssl:verify-certificate no"` for that session |
| FTP upload dropped | Re-run the same upload; `mirror` resumes |
| Rollback skips files | Ensure rollback includes `--transfer-all` |
| BUILD-ID shows the wrong package | The package went to the wrong site's folder; restore and upload correctly |
| `#/tasks` or `#/inbox` opens Home | If the fragment is present, reload once; if missing, inspect the decoded e-mail URL |
| No digest | Check the rolling 24-hour throttle, working hours, `NOTIFY_ENABLED`, sweep state, and shadow mode |
| Bulk row disappears | Create a fresh ZTEST record and repeat without refreshing the form |
| `obscheck` reports an e-mail | Replace it with a role such as "the assignee" |
| `obscheck` reports Safe Links or signed URL | Record only the decoded, redacted link shape |
| S2/S3 remains `(owner)` | Edit those two step prefixes to `(done YYYY-MM-DD)` and rerun readiness checks |
| Generator says `stale - run: npm run X` | Run X, then `docsite` and `docs:catalogue`, then re-check |
| A targeted suite exits 124 | Re-run that suite; CI remains the browser arbiter |
| Playwright fails locally on Android | Expected; do not install browsers in Termux; use CI |
| Evidence PR pin drift | Merge current base, keep both histories, rerun helper/generators/gates |
| `git stash pop` conflicts on ledger | Keep stashed owner ledger with `git checkout --theirs -- "$LEDGER"` |
| `gh pr merge --merge` is refused | Use `--squash` only if repository policy permits and provenance remains acceptable |

---

# Reference

## SharePoint lists used

| Site | List |
|---|---|
| NEDMS | Portal Registry |
| NITDADGO-EAAACTIVITYTRACKING | DGO DIGITAL OPS |
| NITDADGO-EAAACTIVITYTRACKING | Global Tracking Queue |
| NITDADGO-EAAACTIVITYTRACKING | DGO_TaskReminders |
| NITDADGO-EAAACTIVITYTRACKING | Flow Configuration |
| Global_Digital_Documents_Centre | Portal Outbox Receipts |
| Configured identity-map site | DGO_IdentityMap |

## Evidence that must be retained

- Recorded pre-apply, apply, and post-apply flows reports.
- Successful sweep inspection.
- Bulk inspection if available.
- Owner observations with five journeys.
- Config-build ledger entry.
- GitHub PR and CI history.

## Evidence that must not be committed

- FTP passwords.
- Microsoft device codes or session files.
- Signed Power Automate URLs.
- Safe Links wrappers.
- Personal e-mail addresses.
- Raw tenant exports.
- `flows-backup-*.json`.
- `~/runs.json`.
- The private config-build output folder.

## Final sign-off

```text
[ ] PR #89 green and merged
[ ] PR #89 default-branch push green
[ ] PR #90 green and merged after #89
[ ] PR #90 default-branch push green
[ ] Releases 62 and 63 UP_TO_DATE
[ ] Workspace BUILD-ID matches ledger
[ ] Centre BUILD-ID matches ledger
[ ] Digest reference opens task without acknowledgement
[ ] Reminder opens task without acknowledgement
[ ] Bulk-failure opens Inbox
[ ] Assignee receipt persists and another browser reads it
[ ] Other person's link saves no receipt
[ ] Test data removed; receipts/audit retained
[ ] ITEM-106 RESOLVED with dated evidence
[ ] Evidence PR and push run green
[ ] Private files removed; wake lock released
```
