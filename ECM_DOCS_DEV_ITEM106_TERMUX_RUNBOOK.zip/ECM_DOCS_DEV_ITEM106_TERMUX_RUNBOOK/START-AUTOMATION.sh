#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.local/share/item106-automation"
NEXT_DIR="$HOME/.local/share/item106-automation.next"

if ! command -v pkg >/dev/null 2>&1; then
  echo "This launcher must run inside Android Termux."
  exit 1
fi

missing=()
for command in git node npm gh zip unzip lftp curl nano timeout; do
  command -v "$command" >/dev/null 2>&1 || missing+=("$command")
done

if ((${#missing[@]})); then
  echo "Installing the required Termux tools..."
  pkg install -y git nodejs-lts gh zip unzip lftp curl nano coreutils
fi

termux-setup-storage >/dev/null 2>&1 || true
termux-wake-lock >/dev/null 2>&1 || true

if [[ "$SOURCE_DIR" != "$INSTALL_DIR" ]]; then
  rm -rf "$NEXT_DIR"
  mkdir -p "$(dirname "$INSTALL_DIR")"
  cp -R "$SOURCE_DIR" "$NEXT_DIR"
  rm -rf "$INSTALL_DIR"
  mv "$NEXT_DIR" "$INSTALL_DIR"
fi
chmod 700 "$INSTALL_DIR/START-AUTOMATION.sh"
chmod 700 "$INSTALL_DIR/scripts/item106-auto.mjs"

cd "$HOME"
exec node "$INSTALL_DIR/scripts/item106-auto.mjs" run
