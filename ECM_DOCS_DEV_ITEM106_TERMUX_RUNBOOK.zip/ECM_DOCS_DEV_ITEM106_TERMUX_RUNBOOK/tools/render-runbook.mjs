import fs from 'node:fs';
import path from 'node:path';

const source = process.argv[2];
const target = process.argv[3];
if (!source || !target) {
  console.error('usage: node render-runbook.mjs <source.md> <target.html>');
  process.exit(2);
}

const text = fs.readFileSync(source, 'utf8').replace(/\r\n/g, '\n');
const escape = (value) => value
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;');
const slugCounts = new Map();
const slug = (value) => {
  const base = value.toLowerCase().replace(/`([^`]+)`/g, '$1')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'section';
  const n = (slugCounts.get(base) || 0) + 1;
  slugCounts.set(base, n);
  return n === 1 ? base : `${base}-${n}`;
};
const inline = (value) => {
  const codes = [];
  let out = value.replace(/`([^`]+)`/g, (_, code) => {
    codes.push(`<code>${escape(code)}</code>`);
    return `\u0000${codes.length - 1}\u0000`;
  });
  out = escape(out)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')
    .replace(/  $/, '<br>');
  return out.replace(/\u0000(\d+)\u0000/g, (_, n) => codes[Number(n)]);
};

const lines = text.split('\n');
const body = [];
const toc = [];
let paragraph = [];
let list = null;
let quote = [];
const flushParagraph = () => {
  if (paragraph.length) body.push(`<p>${inline(paragraph.join(' '))}</p>`);
  paragraph = [];
};
const flushList = () => {
  if (list) body.push(`</${list}>`);
  list = null;
};
const flushQuote = () => {
  if (quote.length) body.push(`<blockquote>${inline(quote.join(' '))}</blockquote>`);
  quote = [];
};
const flushAll = () => {
  flushParagraph();
  flushList();
  flushQuote();
};

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  if (line.startsWith('```')) {
    flushAll();
    const language = line.slice(3).trim();
    const code = [];
    while (++i < lines.length && !lines[i].startsWith('```')) code.push(lines[i]);
    body.push(`<pre><code${language ? ` class="language-${escape(language)}"` : ''}>${escape(code.join('\n'))}</code></pre>`);
    continue;
  }
  const heading = /^(#{1,6})\s+(.+)$/.exec(line);
  if (heading) {
    flushAll();
    const level = heading[1].length;
    const id = slug(heading[2]);
    if (level <= 3) toc.push({ level, id, text: heading[2].replace(/`/g, '') });
    body.push(`<h${level} id="${id}">${inline(heading[2])}</h${level}>`);
    continue;
  }
  if (/^---+$/.test(line.trim())) {
    flushAll();
    body.push('<hr>');
    continue;
  }
  if (line.includes('|') && i + 1 < lines.length
      && /^\s*\|?[\s:|-]+\|[\s:|-]+/.test(lines[i + 1])) {
    flushAll();
    const rows = [];
    const split = (row) => row.trim().replace(/^\||\|$/g, '').split('|').map((x) => x.trim());
    const headers = split(line);
    i++;
    while (i + 1 < lines.length && lines[i + 1].includes('|') && lines[i + 1].trim()) {
      rows.push(split(lines[++i]));
    }
    body.push('<div class="table-wrap"><table><thead><tr>'
      + headers.map((x) => `<th>${inline(x)}</th>`).join('')
      + '</tr></thead><tbody>'
      + rows.map((row) => `<tr>${row.map((x) => `<td>${inline(x)}</td>`).join('')}</tr>`).join('')
      + '</tbody></table></div>');
    continue;
  }
  const bullet = /^\s*[-*]\s+(.+)$/.exec(line);
  const numbered = /^\s*\d+\.\s+(.+)$/.exec(line);
  if (bullet || numbered) {
    flushParagraph();
    flushQuote();
    const kind = numbered ? 'ol' : 'ul';
    if (list !== kind) {
      flushList();
      list = kind;
      body.push(`<${kind}>`);
    }
    let value = (bullet || numbered)[1];
    const checkbox = /^\[([ xX])\]\s+(.+)$/.exec(value);
    if (checkbox) {
      value = `<input type="checkbox" disabled${checkbox[1].toLowerCase() === 'x' ? ' checked' : ''}> ${inline(checkbox[2])}`;
    } else {
      value = inline(value);
    }
    body.push(`<li>${value}</li>`);
    continue;
  }
  const blockquote = /^>\s?(.*)$/.exec(line);
  if (blockquote) {
    flushParagraph();
    flushList();
    quote.push(blockquote[1]);
    continue;
  }
  if (!line.trim()) {
    flushAll();
    continue;
  }
  paragraph.push(line.trim());
}
flushAll();

const tocHtml = toc.filter((x) => x.level >= 2).map((x) =>
  `<li class="level-${x.level}"><a href="#${x.id}">${escape(x.text)}</a></li>`).join('');
const title = toc.find((x) => x.level === 1)?.text || path.basename(source);
const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escape(title)}</title>
<style>
:root{color-scheme:light;--ink:#17202a;--muted:#52606d;--line:#d9e2ec;--paper:#fff;--soft:#f5f7fa;--accent:#0969da;--warn:#fff8c5}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#eef2f6;color:var(--ink);font:16px/1.55 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.page{max-width:980px;margin:0 auto;background:var(--paper);min-height:100vh;padding:32px 42px 80px;box-shadow:0 0 24px #17202a18}
h1{font-size:2rem;line-height:1.2;margin:.4em 0}h2{font-size:1.55rem;border-bottom:1px solid var(--line);padding-bottom:.25em;margin-top:2em}h3{font-size:1.2rem;margin-top:1.6em}
h4,h5,h6{margin-top:1.4em}a{color:var(--accent)}p{margin:.75em 0}hr{border:0;border-top:2px solid var(--line);margin:2.2em 0}
code{font:0.92em ui-monospace,SFMono-Regular,Consolas,monospace;background:#eff3f6;border-radius:4px;padding:.12em .35em}
pre{background:#0d1117;color:#e6edf3;border-radius:8px;padding:14px;overflow:auto;white-space:pre-wrap;word-break:break-word}
pre code{background:transparent;padding:0;color:inherit}blockquote{margin:1em 0;padding:.6em 1em;border-left:4px solid var(--accent);background:var(--soft)}
.toc{background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:16px 22px;margin:1.5em 0}.toc h2{border:0;margin:.1em 0 .5em;font-size:1.2rem}.toc ul{columns:2;padding-left:1.2em}.toc .level-3{margin-left:1em;font-size:.93em}
.table-wrap{overflow-x:auto;margin:1em 0}table{border-collapse:collapse;width:100%;font-size:.94em}th,td{border:1px solid var(--line);padding:8px 10px;text-align:left;vertical-align:top}th{background:var(--soft)}
li{margin:.28em 0}input[type=checkbox]{width:1em;height:1em}.print{position:fixed;right:16px;bottom:16px;background:var(--accent);color:white;border:0;border-radius:24px;padding:10px 16px;font-weight:600;box-shadow:0 3px 12px #0003}
@media(max-width:700px){body{background:#fff;font-size:15px}.page{padding:18px 16px 64px;box-shadow:none}.toc ul{columns:1}h1{font-size:1.65rem}h2{font-size:1.35rem}.print{position:static;margin:10px 0}}
@media print{body{background:#fff;font-size:10pt}.page{max-width:none;padding:0;box-shadow:none}.print{display:none}.toc ul{columns:2}pre{white-space:pre-wrap;break-inside:avoid}table{font-size:8.5pt}h1,h2,h3{break-after:avoid}.table-wrap{overflow:visible}}
</style>
</head>
<body>
<main class="page">
<button class="print" onclick="window.print()">Print / save PDF</button>
<nav class="toc"><h2>Contents</h2><ul>${tocHtml}</ul></nav>
${body.join('\n')}
</main>
</body>
</html>
`;
fs.writeFileSync(target, html);
console.log(`Rendered ${source} -> ${target}`);
