ONE-COMMAND ITEM-106 AUTOMATION
===============================

WHAT IT AUTOMATES
-----------------
- PR #89 and PR #90 green checks, merge order, and default-branch push CI
- Repository clone/update and targeted local checks
- Microsoft Flow sign-in handoff
- Releases 62 and 63 check/apply/readback
- Config build and build identity
- FTP backup, Centre upload, Workspace upload, and BUILD-ID verification
- Evidence reports, observations JSON, readiness update, generators, checks
- Evidence commit, PR, bounded CI watch, merge, and final verification
- Targeted private-file cleanup; Flow and FTP rollback backups are retained
  for about one week

WHAT STILL NEEDS YOU
--------------------
Microsoft requires you to complete device sign-in. FTP requires passwords.
Real Outlook/Workspace behavior and production test-data cleanup require a
human observation. The automation asks one short question at each unavoidable
checkpoint, saves progress, and resumes without repeating completed stages.

START
-----
1. Extract the ZIP.
2. Open Termux.
3. Run:

   bash ~/storage/downloads/ECM_DOCS_DEV_ITEM106_TERMUX_RUNBOOK/START-AUTOMATION.sh

If Android extracted it somewhere else, replace the path with that folder.

RESUME
------
Run the same command again. State is kept privately at:

  ~/.item106-automation/state.json

STATUS
------
  node ~/.local/share/item106-automation/scripts/item106-auto.mjs status

SAFETY
------
- The automation requires the exact approval phrase before any write.
- CI is watched in foreground for at most 14 bounded nine-minute rounds.
- FTP passwords are never saved.
- FTP control, data, and directory-list traffic is forced through TLS.
- It never uses FTP --delete.
- It backs up each site before upload.
- A backup restore replaces prior files but cannot automatically remove new
  files added by a failed upload; the script calls this out before rollback.
- The Centre and Workspace cannot use the same FTP username/folder pair.
- It validates all five flow packages before and after apply.
- If a live journey fails, ITEM-106 becomes APPLIED_UNVERIFIED, not RESOLVED.
- Evidence work checkpoints after helper, commit, PR, merge, and push CI.
- Any error stops at a resumable checkpoint without repeating completed work.
