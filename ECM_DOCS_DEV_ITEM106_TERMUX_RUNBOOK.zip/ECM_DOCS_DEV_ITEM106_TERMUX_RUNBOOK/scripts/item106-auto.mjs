#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const SCRIPT = fileURLToPath(import.meta.url);
const BUNDLE = path.resolve(path.dirname(SCRIPT), '..');
const HOME = os.homedir();
const AUTO_HOME = path.resolve(process.env.ITEM106_AUTO_HOME || path.join(HOME, '.item106-automation'));
const PRIVATE = path.join(AUTO_HOME, 'private');
const STATE_FILE = path.join(AUTO_HOME, 'state.json');
const LOG_FILE = path.join(AUTO_HOME, 'automation.log');
const REPO = path.resolve(process.env.ITEM106_REPO || path.join(HOME, 'ECM_DOCS_DEV'));
const GH_REPO = 'dgoeaa/ECM_DOCS_DEV';
const BASE_BRANCH = 'claude/system-remediation-gaps-ahpmsy';
const FLOW_IDS = Object.freeze({
  dynamic: '31c0aaf0-ddbb-478c-9a98-bc013265c4c7',
  fetch: 'b79e6707-df4d-4ae7-8a65-738aa45e9a73',
  bulk: '5aab9e61-ab9f-4af1-9f2b-eaba23a1bf06',
  sweep: '8c19b45c-4174-4d2f-9429-ffd08dd1a5ae',
  scan: '197527c8-e76c-4f7d-81b8-3cb5c88b1c6c',
});
const RELEASE_62 = [FLOW_IDS.dynamic, FLOW_IDS.fetch];
const RELEASE_63 = [FLOW_IDS.bulk, FLOW_IDS.sweep, FLOW_IDS.scan];
const ALL_FLOWS = [...RELEASE_62, ...RELEASE_63];
const FLOW_SELECTORS = ALL_FLOWS.map((x) => x.slice(0, 8)).join(',');
const REQUIRED_CHECKS = new Set([
  'Full gate',
  'Smoke tests (chromium)',
  'Smoke tests (firefox)',
  'Smoke tests (webkit)',
  'Link check',
  'Module graph',
  'Secret scan',
]);
const CI_ROUNDS = Number(process.env.ITEM106_CI_ROUNDS || 14);
const CHECK_TIMEOUT = Number(process.env.ITEM106_CHECK_TIMEOUT || 900);
const STAGES = [
  'preflight',
  'repository',
  'signin',
  'flows',
  'build',
  'publish',
  'day0',
  'day1',
  'evidence',
  'final',
  'done',
];
const GENERATORS = [
  'flowreq',
  'plan',
  'disposition',
  'outstanding',
  'platform',
  'flows:regenerate',
  'docsite',
  'docs:catalogue',
];
const CHECKS = [
  'test:secrets',
  'test:readiness',
  'test:plan',
  'test:disposition',
  'test:outstanding',
  'test:platform',
  'test:console',
  'test:flowreq',
  'test:closure',
  'test:docmigration',
  'test:docsite',
  'test:catalogue',
  'test:runbook',
  'test:governancerunbook',
  'test:links',
  'test:deeplinks',
  'test:ackactor',
  'test:idrelease',
  'test:idphase3',
  'test:idphase4',
  'test:governancewalkthrough',
  'test:estateregister',
  'test:productiontrace',
  'test:flowsupdate',
  'test:configbuild',
  'test:endpointregister',
  'test:commissioningauthority',
  'test:imports',
];
const WORKSPACE_URL = 'https://folio-platform.page.gd/';
const CENTRE_BUILD_URL = 'https://folio-cac.page.gd/BUILD-ID.json?x=1';
const WORKSPACE_BUILD_URL = 'https://folio-platform.page.gd/BUILD-ID.json?x=1';
const FLOW_CONFIG_URL = 'https://nitdanigeria.sharepoint.com/sites/NITDADGO-EAAACTIVITYTRACKING/Lists/Flow%20Configuration/AllItems.aspx';
const SWEEP_URL = `https://make.powerautomate.com/environments/Default-ca6a4b3f-9123-49bc-bcb9-27085ebbf1a1/flows/${FLOW_IDS.sweep}/details`;

fs.mkdirSync(PRIVATE, { recursive: true, mode: 0o700 });
try { fs.chmodSync(AUTO_HOME, 0o700); fs.chmodSync(PRIVATE, 0o700); } catch { /* best effort */ }

const stamp = () => new Date().toISOString();
const utcDay = () => stamp().slice(0, 10);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const shellQuote = (value) => `'${String(value).replaceAll("'", "'\\''")}'`;
const relativeRepo = (file) => path.relative(REPO, file).split(path.sep).join('/');
const exists = (file) => fs.existsSync(file);
const unique = (values) => [...new Set(values)];

function appendLog(message) {
  const line = `[${stamp()}] ${message}\n`;
  fs.appendFileSync(LOG_FILE, line, { mode: 0o600 });
  try { fs.chmodSync(LOG_FILE, 0o600); } catch { /* best effort */ }
}

function say(message = '') {
  console.log(message);
  appendLog(String(message).replace(/[^\x20-\x7e]/g, '?'));
}

function heading(message) {
  say(`\n=== ${message} ===`);
}

function fail(message) {
  throw new Error(message);
}

function commandExists(name) {
  const r = spawnSync('sh', ['-c', `command -v ${shellQuote(name)} >/dev/null 2>&1`]);
  return r.status === 0;
}

function run(command, args = [], {
  cwd = REPO,
  env = process.env,
  accept = [0],
  capture = false,
  input = 'ignore',
  quiet = false,
} = {}) {
  if (!quiet) appendLog(`run: ${command} ${args.map((x) => String(x)).join(' ')}`);
  const r = spawnSync(command, args, {
    cwd,
    env,
    encoding: capture ? 'utf8' : undefined,
    maxBuffer: 64 * 1024 * 1024,
    stdio: capture ? [input, 'pipe', 'pipe'] : 'inherit',
  });
  if (r.error) fail(`${command}: ${r.error.message}`);
  const status = r.status ?? 1;
  if (!accept.includes(status)) {
    const detail = capture ? `${r.stdout || ''}${r.stderr || ''}`.trim().slice(-4000) : '';
    fail(`${command} exited ${status}${detail ? `:\n${detail}` : ''}`);
  }
  return { status, stdout: r.stdout || '', stderr: r.stderr || '' };
}

function capture(command, args = [], options = {}) {
  return run(command, args, { ...options, capture: true });
}

function git(args, options = {}) {
  return run('git', args, options);
}

function gh(args, options = {}) {
  return run('gh', args, options);
}

function npm(args, options = {}) {
  return run('npm', args, options);
}

function parseJson(text, label) {
  try { return JSON.parse(text); } catch (e) { fail(`${label}: invalid JSON (${e.message})`); }
}

function loadState() {
  if (!exists(STATE_FILE)) {
    return {
      schema: 'item106-termux-automation/v1',
      stage: 'preflight',
      completed: [],
      createdUtc: stamp(),
      repo: REPO,
      data: {},
    };
  }
  const state = parseJson(fs.readFileSync(STATE_FILE, 'utf8'), STATE_FILE);
  if (state.schema !== 'item106-termux-automation/v1' || !STAGES.includes(state.stage)) {
    fail(`${STATE_FILE}: unsupported automation state`);
  }
  return state;
}

let state = loadState();

function saveState() {
  state.updatedUtc = stamp();
  const tmp = `${STATE_FILE}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
  fs.chmodSync(tmp, 0o600);
  fs.renameSync(tmp, STATE_FILE);
}

function advance(next) {
  if (!STAGES.includes(next)) fail(`Unknown next stage: ${next}`);
  state.completed = unique([...state.completed, state.stage]);
  state.stage = next;
  state.lastError = null;
  saveState();
}

async function ask(question, { required = true, validate = null } = {}) {
  for (;;) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    let answer;
    try { answer = (await rl.question(`${question} `)).trim(); } finally { rl.close(); }
    if (!answer && required) { say('A value is required.'); continue; }
    if (validate) {
      const error = validate(answer);
      if (error) { say(error); continue; }
    }
    return answer;
  }
}

async function yesNo(question, defaultYes = false) {
  const suffix = defaultYes ? '[Y/n]' : '[y/N]';
  for (;;) {
    const answer = (await ask(`${question} ${suffix}`, { required: false })).toLowerCase();
    if (!answer) return defaultYes;
    if (['y', 'yes'].includes(answer)) return true;
    if (['n', 'no'].includes(answer)) return false;
    say('Enter y or n.');
  }
}

function askSecret(prompt) {
  const script = 'IFS= read -r -s -p "$1" value; printf "\\n%s" "$value"';
  const r = spawnSync('bash', ['-c', script, 'bash', prompt], {
    encoding: 'utf8',
    stdio: ['inherit', 'pipe', 'inherit'],
  });
  if (r.status !== 0) fail('Could not read the password.');
  return r.stdout.replace(/^\n/, '');
}

function openUrl(url) {
  say(`Open: ${url}`);
  if (commandExists('termux-open-url')) {
    run('termux-open-url', [url], { cwd: HOME, accept: [0, 1], quiet: true });
  }
}

function watParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Lagos',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    hourCycle: 'h23',
    weekday: 'short',
  }).formatToParts(date);
  return Object.fromEntries(parts.map((x) => [x.type, x.value]));
}

function watDay(date = new Date()) {
  const p = watParts(date);
  return `${p.year}-${p.month}-${p.day}`;
}

function nextWeekday(day) {
  const d = new Date(`${day}T12:00:00Z`);
  do { d.setUTCDate(d.getUTCDate() + 1); } while ([0, 6].includes(d.getUTCDay()));
  return d.toISOString().slice(0, 10);
}

function redactSafe(value) {
  if (/[\w.+-]+@[\w-]+\.[a-z][\w.-]*/i.test(value)) return 'Do not enter an e-mail address; use a role such as "the assignee".';
  if (/[?&](sig|sp|sv)=/i.test(value) || /safelinks|url=https?%3a/i.test(value)) return 'Do not enter a signed URL or Safe Links wrapper.';
  return null;
}

function loadEnvironmentFile(file, cwd = REPO) {
  const r = spawnSync('bash', ['-c', 'set -a; source "$1"; env -0', 'bash', file], {
    cwd,
    encoding: 'utf8',
    maxBuffer: 8 * 1024 * 1024,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  if (r.error) fail(`Could not load ${file}: ${r.error.message}`);
  if (r.status !== 0) fail(`Could not load ${file}; bash exited ${r.status}. Fix env.sh, then resume.`);
  const env = { ...process.env };
  for (const pair of r.stdout.split('\0')) {
    const at = pair.indexOf('=');
    if (at > 0) env[pair.slice(0, at)] = pair.slice(at + 1);
  }
  return env;
}

function loadAgentEnv() {
  const file = path.join(HOME, 'NITDA-Folio-Agent', 'env.sh');
  if (!exists(file)) fail(`${file} does not exist; run agent:access setup.`);
  return loadEnvironmentFile(file);
}

function liveNpm(args, options = {}) {
  return npm(args, { ...options, env: loadAgentEnv() });
}

function repoStatus() {
  return capture('git', ['status', '--porcelain'], { cwd: REPO }).stdout.trim();
}

function ensureCleanRepo(context) {
  const status = repoStatus();
  if (status) fail(`${context}: repository has local changes:\n${status}`);
}

function ghJson(args) {
  const r = capture('gh', args, { cwd: REPO });
  return parseJson(r.stdout, `gh ${args.join(' ')}`);
}

function parsePrChecks(r, number) {
  if (!r.stdout.trim() && /no checks reported/i.test(r.stderr)) return [];
  if (!r.stdout.trim()) return [];
  try { return JSON.parse(r.stdout); } catch {
    if (/no checks reported/i.test(`${r.stdout}\n${r.stderr}`)) return [];
    fail(`Could not parse checks for PR #${number}: ${(r.stderr || r.stdout).trim()}`);
  }
}

function prChecks(number) {
  const r = capture('gh', ['pr', 'checks', String(number), '-R', GH_REPO, '--json', 'name,bucket,state,link'], {
    cwd: REPO,
    accept: [0, 1, 8],
  });
  return parsePrChecks(r, number);
}

function checkSummary(checks) {
  const byName = new Map(checks.map((x) => [x.name, x]));
  const missing = [...REQUIRED_CHECKS].filter((x) => !byName.has(x));
  const failed = checks.filter((x) => ['fail', 'cancel'].includes(x.bucket));
  const pending = checks.filter((x) => x.bucket === 'pending');
  const requiredPassed = missing.length === 0
    && [...REQUIRED_CHECKS].every((x) => byName.get(x)?.bucket === 'pass');
  return { missing, failed, pending, requiredPassed };
}

async function watchPr(number) {
  let first = prChecks(number);
  for (let attempt = 0; !first.length && attempt < 36; attempt++) {
    say(`PR #${number} has not reported checks yet; waiting 15 seconds.`);
    await sleep(15000);
    first = prChecks(number);
  }
  if (!first.length) fail(`PR #${number} reported no checks after 9 minutes. Run this automation again to resume.`);
  for (let round = 1; round <= CI_ROUNDS; round++) {
    const before = checkSummary(prChecks(number));
    if (before.failed.length) fail(`PR #${number} failed: ${before.failed.map((x) => x.name).join(', ')}`);
    if (before.requiredPassed && before.pending.length === 0) return;
    say(`Watching PR #${number}, bounded round ${round}/${CI_ROUNDS}...`);
    run('timeout', ['540', 'gh', 'pr', 'checks', String(number), '-R', GH_REPO, '--watch', '--interval', '30'], {
      cwd: REPO,
      accept: [0, 1, 8, 124],
    });
    const after = checkSummary(prChecks(number));
    if (after.failed.length) fail(`PR #${number} failed: ${after.failed.map((x) => `${x.name} (${x.link})`).join(', ')}`);
    if (after.requiredPassed && after.pending.length === 0) return;
    say(`PR #${number} is still running after ${round * 9} minutes.`);
  }
  fail(`PR #${number} did not finish within ${CI_ROUNDS * 9} minutes. Run this automation again to resume.`);
}

async function watchRun(runId, { commit = null, recovered = false } = {}) {
  let currentRun = runId;
  for (let round = 1; round <= CI_ROUNDS; round++) {
    const view = ghJson(['run', 'view', String(currentRun), '-R', GH_REPO, '--json', 'status,conclusion,url']);
    if (view.status === 'completed') {
      if (view.conclusion === 'success') return;
      if (view.conclusion === 'cancelled' && commit && !recovered) {
        git(['fetch', '-q', 'origin', BASE_BRANCH], { cwd: REPO });
        const latest = capture('git', ['rev-parse', `origin/${BASE_BRANCH}`], { cwd: REPO }).stdout.trim();
        const contains = run('git', ['merge-base', '--is-ancestor', commit, latest], { cwd: REPO, accept: [0, 1] }).status === 0;
        if (contains && latest !== commit) {
          say(`Run ${currentRun} was cancelled by newer default-branch work; watching the green successor for ${latest.slice(0, 8)}.`);
          const replacement = await pushRunForCommit(latest);
          return watchRun(replacement, { commit: latest, recovered: true });
        }
        gh(['run', 'rerun', String(currentRun), '-R', GH_REPO], { cwd: REPO });
        await sleep(10000);
        const replacement = await pushRunForCommit(commit);
        return watchRun(replacement, { commit, recovered: true });
      }
      if (view.conclusion === 'failure') {
        const meta = ghJson(['api', `/repos/${GH_REPO}/actions/runs/${currentRun}`]);
        if (Number(meta.run_attempt || 1) === 1) {
          say(`CI run ${currentRun} failed on its first attempt; rerunning failed jobs once.`);
          gh(['run', 'rerun', String(currentRun), '-R', GH_REPO, '--failed'], { cwd: REPO });
          for (let attempt = 0; attempt < 18; attempt++) {
            await sleep(5000);
            const refreshed = ghJson(['api', `/repos/${GH_REPO}/actions/runs/${currentRun}`]);
            if (Number(refreshed.run_attempt || 1) > 1 || refreshed.status !== 'completed') break;
          }
          return watchRun(currentRun, { commit, recovered });
        }
      }
      fail(`CI run ${currentRun} concluded ${view.conclusion}: ${view.url}`);
    }
    say(`Watching push run ${currentRun}, bounded round ${round}/${CI_ROUNDS}...`);
    run('timeout', ['540', 'gh', 'run', 'watch', String(currentRun), '-R', GH_REPO, '--exit-status', '--interval', '30', '--compact'], {
      cwd: REPO,
      accept: [0, 1, 124],
    });
    const after = ghJson(['run', 'view', String(currentRun), '-R', GH_REPO, '--json', 'status,conclusion,url']);
    if (after.status === 'completed') {
      if (after.conclusion === 'success') return;
      if (after.conclusion === 'cancelled' && commit && !recovered) {
        return watchRun(currentRun, { commit, recovered });
      }
      if (after.conclusion === 'failure') return watchRun(currentRun, { commit, recovered });
      fail(`CI run ${currentRun} concluded ${after.conclusion}: ${after.url}`);
    }
  }
  fail(`CI run ${currentRun} did not finish within ${CI_ROUNDS * 9} minutes. Run this automation again to resume.`);
}

async function pushRunForCommit(commit) {
  for (let i = 0; i < 12; i++) {
    const runs = ghJson([
      'run', 'list', '-R', GH_REPO, '--workflow', 'ci.yml', '--commit', commit,
      '--event', 'push', '--limit', '1', '--json', 'databaseId,status,conclusion,url',
    ]);
    if (runs[0]?.databaseId) return runs[0].databaseId;
    await sleep(10000);
  }
  fail(`No default-branch push run appeared for ${commit.slice(0, 8)}.`);
}

async function ensurePrMerged(number) {
  let pr = ghJson([
    'pr', 'view', String(number), '-R', GH_REPO,
    '--json', 'state,isDraft,headRefOid,mergeable,mergeStateStatus,mergeCommit,url',
  ]);
  if (pr.state === 'MERGED') {
    say(`PR #${number} is already merged.`);
    const mergeCommit = pr.mergeCommit?.oid || await waitForPrMergeCommit(number);
    const runId = await pushRunForCommit(mergeCommit);
    await watchRun(runId, { commit: mergeCommit });
    return mergeCommit;
  }
  if (pr.state !== 'OPEN') fail(`PR #${number} is ${pr.state}, not mergeable.`);
  if (pr.isDraft) gh(['pr', 'ready', String(number), '-R', GH_REPO]);
  if (pr.mergeStateStatus === 'BEHIND') {
    say(`Updating PR #${number} with the current default branch.`);
    gh(['pr', 'update-branch', String(number), '-R', GH_REPO]);
  }
  if (pr.mergeStateStatus === 'DIRTY' || pr.mergeable === 'CONFLICTING') {
    fail(`PR #${number} has conflicts. It needs a repository agent before automation can continue.`);
  }
  await watchPr(number);
  pr = ghJson([
    'pr', 'view', String(number), '-R', GH_REPO,
    '--json', 'state,headRefOid,mergeable,mergeStateStatus',
  ]);
  if (pr.state !== 'OPEN' || pr.mergeable === 'CONFLICTING') fail(`PR #${number} changed while checks ran.`);
  gh([
    'pr', 'merge', String(number), '-R', GH_REPO, '--merge',
    '--match-head-commit', pr.headRefOid,
  ]);
  const merged = ghJson(['pr', 'view', String(number), '-R', GH_REPO, '--json', 'state,mergeCommit']);
  if (merged.state !== 'MERGED') fail(`PR #${number} did not merge.`);
  const mergeCommit = merged.mergeCommit?.oid || await waitForPrMergeCommit(number);
  const runId = await pushRunForCommit(mergeCommit);
  await watchRun(runId, { commit: mergeCommit });
  return mergeCommit;
}

function reportFiles(kind = null, dir = path.join(PRIVATE, 'flows')) {
  if (!exists(dir)) return [];
  return fs.readdirSync(dir)
    .filter((name) => /^flows-(check|apply)-.+\.json$/.test(name))
    .filter((name) => !kind || name.startsWith(`flows-${kind}-`))
    .map((name) => path.join(dir, name))
    .sort((a, b) => fs.statSync(a).mtimeMs - fs.statSync(b).mtimeMs);
}

function newestReport(kind, before = new Set(), dir = path.join(PRIVATE, 'flows')) {
  const files = reportFiles(kind, dir).filter((x) => !before.has(x));
  const chosen = files.at(-1);
  if (!chosen) fail(`flows:update did not write a ${kind} report.`);
  return chosen;
}

function flattenReport(file) {
  const report = parseJson(fs.readFileSync(file, 'utf8'), file);
  if (report.schema !== 'folio-flows-update-report/v1') fail(`${file}: not a flows:update report`);
  const rows = [];
  for (const flow of report.flows || []) {
    for (const pkg of flow.packages || []) rows.push({ flowId: flow.flowId, flow: flow.flow, ...pkg });
  }
  return { report, rows };
}

function validateReport(file, expectedIds, allowedStatuses, exact = true) {
  const { rows } = flattenReport(file);
  const ids = unique(rows.map((x) => x.flowId.toLowerCase()));
  const expected = expectedIds.map((x) => x.toLowerCase());
  const unknown = ids.filter((x) => !expected.includes(x));
  const missing = exact ? expected.filter((x) => !ids.includes(x)) : [];
  const bad = rows.filter((x) => !allowedStatuses.includes(x.status));
  if (unknown.length || missing.length || bad.length) {
    fail(`${path.basename(file)} failed validation.\n`
      + `Unexpected flows: ${unknown.join(', ') || 'none'}\n`
      + `Missing flows: ${missing.join(', ') || 'none'}\n`
      + `Bad states: ${bad.map((x) => `${x.flow}:${x.status}`).join(', ') || 'none'}`);
  }
  return rows;
}

function buildIdentity(tree) {
  const file = path.join(tree, 'BUILD-ID.json');
  if (!exists(file)) fail(`Missing ${file}`);
  return parseJson(fs.readFileSync(file, 'utf8'), file);
}

function validateFtpUser(value) {
  return /^[A-Za-z0-9._-]+$/.test(value) ? null : 'Use only letters, numbers, dot, underscore, or hyphen.';
}

function validateRemoteDir(value) {
  if (!/^\/[A-Za-z0-9._/-]+$/.test(value) || value.includes('..')) return 'Enter an absolute FTP folder such as /htdocs, without ..';
  return null;
}

function lftpQuote(value) {
  return `"${String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"`;
}

function ftpTlsCommands(allowInsecure = false, ca = process.env.PREFIX ? path.join(process.env.PREFIX, 'etc/tls/cert.pem') : '') {
  const verify = allowInsecure || !ca || !exists(ca) ? 'set ssl:verify-certificate no' : `set ssl:ca-file ${lftpQuote(ca)}`;
  return `set ftp:ssl-force true; set ftp:ssl-protect-data true; set ftp:ssl-protect-list true; ${verify}`;
}

function ftpRun(user, password, script, { captureOutput = false, allowInsecure = false } = {}) {
  const tls = ftpTlsCommands(allowInsecure);
  return run('lftp', ['--env-password', '-u', user, '-e', `${tls}; ${script}; bye`, 'ftpupload.net'], {
    cwd: HOME,
    env: { ...process.env, LFTP_PASSWORD: password },
    capture: captureOutput,
  });
}

async function ftpWithFallback(user, password, script, options = {}) {
  try { return ftpRun(user, password, script, options); } catch (e) {
    say(e.message);
    if (!(await yesNo('If the FTP error explicitly mentioned certificate validation, retry with verification disabled?', false))) throw e;
    return ftpRun(user, password, script, { ...options, allowInsecure: true });
  }
}

function parseJsonFromOutput(output, label) {
  const start = output.indexOf('{');
  const end = output.lastIndexOf('}');
  if (start < 0 || end < start) fail(`${label}: no JSON object was returned`);
  return parseJson(output.slice(start, end + 1), label);
}

async function publishSite(key, label, localTree, expectedPackage) {
  state.data.publish ||= {};
  if (state.data.publish[key]?.verified) {
    say(`${label} is already marked published and verified.`);
    return;
  }
  heading(`Publish ${label}`);
  const prior = state.data.publish[key] || {};
  if (prior.backedUp && (!prior.user || !prior.remoteDir || !prior.backup || !exists(prior.backup))) {
    fail(`${label} is marked backed up, but its saved backup checkpoint is incomplete.`);
  }
  const user = prior.backedUp
    ? prior.user
    : await ask(`FTP username for ${label}${prior.user ? ` [${prior.user}]` : ''}:`, {
      required: !prior.user,
      validate: (v) => v ? validateFtpUser(v) : null,
    }) || prior.user;
  const enteredDir = prior.backedUp
    ? prior.remoteDir
    : await ask(`FTP site-root folder for ${label}${prior.remoteDir ? ` [${prior.remoteDir}]` : ' [/htdocs]'}:`, {
      required: false,
      validate: (v) => v ? validateRemoteDir(v) : null,
    }) || prior.remoteDir || '/htdocs';
  const remoteDir = enteredDir === '/' ? '/' : enteredDir.replace(/\/+$/, '');
  const other = Object.entries(state.data.publish)
    .find(([otherKey, value]) => {
      const otherDir = value?.remoteDir === '/' ? '/' : value?.remoteDir?.replace(/\/+$/, '');
      return otherKey !== key && value?.user === user && otherDir === remoteDir;
    });
  if (other) fail(`${label} uses the same FTP username and folder as ${other[0]}; refusing to overwrite the other site.`);
  const password = askSecret(`FTP password for ${user}: `);
  if (!password) fail('FTP password is required.');
  const backup = path.join(PRIVATE, 'site-backup', `${key}-before`);
  if (!prior.backedUp) {
    fs.rmSync(backup, { recursive: true, force: true });
    fs.mkdirSync(backup, { recursive: true, mode: 0o700 });
    say(`Backing up ${label} before upload...`);
    await ftpWithFallback(user, password,
      `mirror --no-perms ${lftpQuote(`${remoteDir}/`)} ${lftpQuote(`${backup}/`)}`);
    state.data.publish[key] = { user, remoteDir, backup, backedUp: true, verified: false };
    saveState();
  }
  say(`Uploading ${label} without deleting remote-only files...`);
  await ftpWithFallback(user, password,
    `mirror -R --no-perms --transfer-all --verbose ${lftpQuote(`${localTree}/`)} ${lftpQuote(`${remoteDir}/`)}`);
  const read = await ftpWithFallback(user, password,
    `cat ${lftpQuote(`${remoteDir}/BUILD-ID.json`)}`, { captureOutput: true });
  const id = parseJsonFromOutput(`${read.stdout}\n${read.stderr}`, `${label} BUILD-ID.json`);
  const expected = state.data.build;
  const matches = id.package === expectedPackage && id.version === expected.version && id.commit === expected.commit;
  if (!matches) {
    say(`${label} BUILD-ID mismatch. Expected ${expectedPackage} v${expected.version} at ${expected.commit}.`);
    if (await yesNo(`Restore prior ${label} files from the backup now? New files added by the failed upload may still need manual removal.`, true)) {
      await ftpWithFallback(user, password,
        `mirror -R --no-perms --transfer-all ${lftpQuote(`${backup}/`)} ${lftpQuote(`${remoteDir}/`)}`);
    }
    fail(`${label} publication did not verify; it was not marked complete.`);
  }
  state.data.publish[key] = { user, remoteDir, backup, backedUp: true, verified: true, buildId: id };
  saveState();
  say(`${label} verified: ${id.package} v${id.version} at ${String(id.commit).slice(0, 8)}.`);
}

async function verifyRemoteSite(key, label, expectedPackage) {
  const saved = state.data.publish?.[key];
  if (!saved) fail(`No saved FTP details for ${label}.`);
  const password = askSecret(`FTP password for ${saved.user} to re-check ${label}: `);
  const read = await ftpWithFallback(saved.user, password,
    `cat ${lftpQuote(`${saved.remoteDir}/BUILD-ID.json`)}`, { captureOutput: true });
  const id = parseJsonFromOutput(`${read.stdout}\n${read.stderr}`, `${label} BUILD-ID.json`);
  const expected = state.data.build;
  if (id.package !== expectedPackage || id.version !== expected.version || id.commit !== expected.commit) {
    fail(`${label} no longer serves the expected build.`);
  }
  return id;
}

async function remember(target, key, question, options = {}) {
  if (!target[key]) {
    target[key] = await ask(question, options);
    saveState();
  }
  return target[key];
}

async function checkResult(name, prompt) {
  state.data.journeys ||= {};
  if (Object.hasOwn(state.data.journeys, name)) return state.data.journeys[name].pass;
  const ok = await yesNo(prompt, false);
  state.data.journeys[name] = { pass: ok };
  if (!ok) {
    state.data.journeys[name].note = await ask('Briefly state what happened (no e-mail addresses or URLs):', {
      validate: redactSafe,
    });
  }
  saveState();
  return ok;
}

function latestInspectionRun(file, since, { requireSuccess = true } = {}) {
  const report = parseJson(fs.readFileSync(file, 'utf8'), file);
  const candidates = (report.runs || [])
    .filter((x) => !since || String(x.startTime || '').slice(0, 10) >= since)
    .filter((x) => !requireSuccess || x.runStatus === 'Succeeded')
    .sort((a, b) => String(b.startTime || '').localeCompare(String(a.startTime || '')));
  return candidates[0] || null;
}

async function inspectLatest(flowId, since, name, requireSuccess = true) {
  const listFile = path.join(PRIVATE, `${name}-runs.json`);
  liveNpm(['run', '-s', 'flows:inspect', '--', '--since', since, '--flow', flowId, '--out', listFile]);
  let selected = latestInspectionRun(listFile, since, { requireSuccess });
  if (!selected) fail(`No suitable ${name} run was found since ${since}.`);
  say(`Latest ${name} run: ${selected.runId} at ${selected.startTime} (${selected.runStatus}).`);
  if (!(await yesNo('Is this the run you just produced?', true))) {
    const report = parseJson(fs.readFileSync(listFile, 'utf8'), listFile);
    for (const r of report.runs || []) say(`  ${r.runId}  ${r.startTime}  ${r.runStatus}`);
    const runId = await ask('Paste the correct run ID:');
    selected = (report.runs || []).find((x) => x.runId === runId);
    if (!selected) fail('That run ID is not in the inspected run list.');
  }
  const out = path.join(PRIVATE, `${state.data.d1 || utcDay()}-inspection-${name}.json`);
  liveNpm(['run', '-s', 'flows:inspect', '--', '--run', selected.runId, '--flow', flowId, '--out', out]);
  return { runId: selected.runId, startTime: selected.startTime, status: selected.runStatus, file: out };
}

function findRecordedEvidence(reportFile) {
  const dir = path.join(REPO, 'docs/folio-Master-Flows-and-Endpoints/evidence');
  const text = fs.readFileSync(reportFile, 'utf8');
  for (const name of fs.readdirSync(dir)) {
    if (!/-flows-(check|apply)(-\d+)?\.json$/.test(name)) continue;
    const file = path.join(dir, name);
    if (fs.readFileSync(file, 'utf8') === text) return relativeRepo(file);
  }
  return null;
}

function recordReport(reportFile) {
  const r = capture('npm', ['run', '-s', 'flows:update', '--', 'record', reportFile], {
    cwd: REPO,
    accept: [0, 2],
  });
  const output = `${r.stdout}\n${r.stderr}`;
  if (r.status === 0) {
    const match = /^Evidence:\s+(.+)$/m.exec(output);
    if (!match) fail(`Could not read the Evidence path from record output for ${reportFile}.`);
    return match[1].trim();
  }
  if (/already recorded/i.test(output)) {
    const existing = findRecordedEvidence(reportFile);
    if (existing) return existing;
  }
  fail(`Could not record ${reportFile}:\n${output.trim()}`);
}

function observationJson() {
  const d = state.data;
  const j = d.journeys || {};
  const result = (key, success, failure) => j[key]?.pass ? success : `${failure} ${j[key]?.note || 'No further note was recorded.'}`;
  return {
    schema: 'folio-owner-observations/v1',
    item: 'ITEM-106',
    observedBy: 'Registry owner (signed in as themself); a colleague for task C',
    days: { setUp: d.d0, observed: d.d1 },
    builds: {
      ledger: d.build.ledger,
      workspace: { host: 'folio-platform.page.gd', version: d.build.version, commit: d.build.commit },
      centre: { host: 'folio-cac.page.gd', version: d.build.version, commit: d.build.commit },
    },
    flows: 'Releases 62 and 63 applied with flows:update and read back UP_TO_DATE; the check and apply reports are filed beside this file.',
    observations: [
      {
        journey: 'bulk-failure',
        record: `${d.records.bulk} (ZTEST-BULK)`,
        subject: 'Bulk assignment: 1 of 1 not completed',
        outboxReceipt: `bulk-failure receipt ${d.receipts.bulk}`,
        link: 'index.html#/inbox',
        result: result('bulk', 'The email arrived; its button opened the Inbox, not an acknowledgement page.', 'The bulk-failure journey did not meet the requirement.'),
        pass: Boolean(j.bulk?.pass),
      },
      {
        journey: 'assignment-link-assignee',
        task: `${d.tasks.b} (task B)`,
        result: result('assignee', "The assignee's own assignment link acknowledged task B; a fresh private tab showed it acknowledged.", 'The assignee journey did not meet the requirement.'),
        pass: Boolean(j.assignee?.pass),
      },
      {
        journey: 'assignment-link-other-person',
        task: `${d.tasks.c} (task C)`,
        result: result('other', "The copied owner opened task C's link and saw that it is assigned to someone else; C stayed awaiting receipt.", 'The other-person journey did not meet the requirement.'),
        pass: Boolean(j.other?.pass),
      },
      {
        journey: 'digest',
        subject: d.subjects.digest,
        outboxReceipt: `task-digest receipt ${d.receipts.digest}`,
        checks: {
          referenceLinkA: result('digestReference', "Task A's reference opened task A (intent=open, source=digest); A stayed awaiting receipt.", 'The digest task-reference check failed.'),
          acknowledgeButton: result('digestAckList', 'The Acknowledge receipt link listed task A only (not B or C).', 'The digest acknowledgement-list check failed.'),
          openMyTasks: result('digestTasks', 'Open my tasks opened the task list (#/tasks).', 'The digest task-list check failed.'),
          acknowledgeSaved: result('digestAcknowledge', 'The Acknowledge receipt button saved task A successfully.', 'The digest acknowledgement-save check failed.'),
        },
        pass: Boolean(j.digestReference?.pass && j.digestAckList?.pass && j.digestTasks?.pass && j.digestAcknowledge?.pass),
      },
      {
        journey: 'reminder',
        subject: d.subjects.reminder,
        outboxReceipt: `task-reminder receipt ${d.receipts.reminder}`,
        link: `index.html?ref=${d.tasks.a}&intent=open&source=reminder`,
        result: result('reminder', 'The reminder opened task A; A stayed awaiting receipt; nothing was acknowledged.', 'The reminder journey did not meet the requirement.'),
        pass: Boolean(j.reminder?.pass),
      },
    ],
    runs: {
      sweep: `AUTO_SCHEDULED_SWEEP run ${d.inspections.sweep.runId} on ${d.d1}: ${d.inspections.sweep.status} (inspection filed beside this file).`,
      bulk: d.inspections.bulk
        ? `BULK_OPS_DATA_RETRIEVAL_HTTP run ${d.inspections.bulk.runId} on ${d.d0}: ${d.inspections.bulk.status} (inspection filed beside this file).`
        : `BULK_OPS_DATA_RETRIEVAL_HTTP run on ${d.d0}: not inspected.`,
    },
    cleanup: `ZTEST records ${[d.records.a, d.records.b, d.records.c, d.records.bulk].join(', ')} and their tasks, reminder, mirror and locator rows removed on ${d.cleanupDay}; Outbox receipts and audit rows kept; counter gaps accepted (offset, no reset), as in MANUAL-2.`,
    redaction: 'No e-mail addresses, signed URLs or Safe Links wrappers recorded: references, run IDs and Outbox receipt IDs only.',
  };
}

function evidenceTargetStatus() {
  const observations = observationJson().observations;
  return observations.every((x) => x.pass === true) ? 'RESOLVED' : 'APPLIED_UNVERIFIED';
}

function evidenceWhyOpen(status) {
  const d = state.data;
  if (status === 'RESOLVED') {
    return `Nothing open on this item: releases 62 and 63 read back UP_TO_DATE on ${d.da}, the Workspace and hosted Centre were published from build ${d.build.version}, and the digest, reminder and bulk-failure journeys were observed as Part 5.2 states.`;
  }
  const open = observationJson().observations.filter((x) => x.pass !== true).map((x) => x.journey.replaceAll('-', ' '));
  return `Releases 62 and 63 read back UP_TO_DATE on ${d.da} and build ${d.build.version} is published to the Workspace and hosted Centre. Still to observe or correct: ${open.join('; ')}.`;
}

function evidenceNote(status) {
  const d = state.data;
  return status === 'RESOLVED'
    ? `ITEM-106 resolved on the owner's evidence: releases 62 and 63 applied and read back, build ${d.build.version} published to the Workspace and hosted Centre, and the five journeys observed between ${d.d0} and ${d.d1}.`
    : `ITEM-106 applied on the owner's evidence: releases 62 and 63 read back and build ${d.build.version} published; the recorded live journeys still need correction or completion.`;
}

function item106() {
  const file = path.join(REPO, 'docs/deployment/PRODUCTION_READINESS_REGISTER.json');
  const register = parseJson(fs.readFileSync(file, 'utf8'), file);
  return { register, item: register.items.find((x) => x.id === 'ITEM-106') };
}

function helperAlreadyApplied(status, refs) {
  const { register, item } = item106();
  if (!item || item.status !== status) return false;
  if (register.compiledAgainstCommit !== capture('git', ['rev-parse', 'HEAD'], { cwd: REPO }).stdout.trim()) return false;
  return refs.every((ref) => item.evidence.some((x) => x.ref === ref));
}

function findStash(message, cwd = REPO) {
  const rows = capture('git', ['stash', 'list', '--format=%gd%x09%s'], { cwd }).stdout.trim().split('\n').filter(Boolean);
  const match = rows.find((row) => row.split('\t').slice(1).join('\t').endsWith(message));
  return match ? match.split('\t')[0] : null;
}

async function waitForPrMergeCommit(number, label = 'PR') {
  for (let attempt = 0; attempt < 18; attempt++) {
    const pr = ghJson(['pr', 'view', String(number), '-R', GH_REPO, '--json', 'state,mergeCommit,url']);
    if (pr.state === 'MERGED' && pr.mergeCommit?.oid) return pr.mergeCommit.oid;
    if (pr.state !== 'MERGED') fail(`${label} #${number} is ${pr.state}, not merged: ${pr.url}`);
    await sleep(5000);
  }
  fail(`${label} #${number} merged, but GitHub did not expose its merge commit within 90 seconds.`);
}

function evidenceResumePoint(evidence) {
  if (evidence.pushRunPassed) return 'final';
  if (evidence.mergeCommit) return 'push';
  if (evidence.pr) return 'pr';
  if (evidence.commit) return 'publish';
  if (evidence.helperApplied) return 'files';
  return 'prepare';
}

async function finishEvidencePr(evidence) {
  if (evidence.pushRunPassed) {
    advance('final');
    return;
  }
  if (!evidence.mergeCommit) {
    let pr = ghJson([
      'pr', 'view', String(evidence.pr), '-R', GH_REPO,
      '--json', 'state,headRefOid,mergeCommit,url',
    ]);
    if (pr.state !== 'MERGED') {
      if (pr.state !== 'OPEN') fail(`Evidence PR #${evidence.pr} is ${pr.state}: ${pr.url}`);
      await watchPr(evidence.pr);
      pr = ghJson([
        'pr', 'view', String(evidence.pr), '-R', GH_REPO,
        '--json', 'state,headRefOid,mergeCommit,url',
      ]);
      if (pr.state !== 'MERGED') {
        gh([
          'pr', 'merge', String(evidence.pr), '-R', GH_REPO, '--merge', '--delete-branch',
          '--match-head-commit', pr.headRefOid,
        ], { cwd: REPO });
      }
    }
    evidence.mergeCommit = pr.mergeCommit?.oid || await waitForPrMergeCommit(evidence.pr, 'Evidence PR');
    saveState();
  }
  if (!evidence.pushRun) {
    evidence.pushRun = await pushRunForCommit(evidence.mergeCommit);
    saveState();
  }
  if (!evidence.pushRunPassed) {
    await watchRun(evidence.pushRun, { commit: evidence.mergeCommit });
    evidence.pushRunPassed = true;
    saveState();
  }
  advance('final');
}

function runGeneratorsAndChecks() {
  const env = {
    ...process.env,
    PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: '1',
    PUPPETEER_SKIP_DOWNLOAD: '1',
  };
  npm(['ci', '--ignore-scripts'], { cwd: REPO, env });
  const logs = path.join(PRIVATE, 'logs');
  fs.mkdirSync(logs, { recursive: true, mode: 0o700 });
  for (const name of GENERATORS) {
    say(`Generator: ${name}`);
    const file = path.join(logs, `gen-${name.replaceAll(':', '_')}.log`);
    const r = capture('npm', ['run', '-s', name], { cwd: REPO, env, accept: [0, 1, 2] });
    fs.writeFileSync(file, `${r.stdout}${r.stderr}`, { mode: 0o600 });
    if (r.status !== 0) fail(`${name} failed. Private log: ${file}`);
  }
  let failures = [];
  for (const name of CHECKS) {
    const file = path.join(logs, `gate-${name.replaceAll(':', '_')}.log`);
    const r = capture('timeout', [String(CHECK_TIMEOUT), 'npm', 'run', '-s', name], { cwd: REPO, env, accept: [0, 1, 2, 124] });
    fs.writeFileSync(file, `${r.stdout}${r.stderr}`, { mode: 0o600 });
    if (r.status === 0) say(`ok    ${name}`);
    else {
      say(`${r.status === 124 ? 'TIMEOUT' : 'FAIL'}  ${name} (exit ${r.status})`);
      failures.push({ name, file, status: r.status });
    }
  }
  if (failures.length) {
    const stale = unique(failures.flatMap(({ file }) => {
      const text = fs.readFileSync(file, 'utf8');
      return [...text.matchAll(/run:\s+npm run\s+([A-Za-z0-9:_-]+)/g)].map((x) => x[1]);
    }));
    if (stale.length) {
      for (const name of stale) npm(['run', '-s', name], { cwd: REPO, env });
      npm(['run', '-s', 'docsite'], { cwd: REPO, env });
      npm(['run', '-s', 'docs:catalogue'], { cwd: REPO, env });
      const retry = [];
      for (const failure of failures) {
        const r = capture('timeout', [String(CHECK_TIMEOUT), 'npm', 'run', '-s', failure.name], { cwd: REPO, env, accept: [0, 1, 2, 124] });
        fs.writeFileSync(failure.file, `${r.stdout}${r.stderr}`, { mode: 0o600 });
        if (r.status !== 0) retry.push({ ...failure, status: r.status });
      }
      failures = retry;
    }
  }
  if (failures.length) fail(`Checks still failing: ${failures.map((x) => `${x.name} (${x.file})`).join(', ')}`);
  run('node', ['scripts/run-test-gate.mjs', '--check'], { cwd: REPO, env });
}

function validateChangedPaths() {
  const status = capture('git', ['status', '--porcelain'], { cwd: REPO }).stdout.trim().split('\n').filter(Boolean);
  const bad = status.filter((line) => {
    const file = line.slice(3).replace(/^"|"$/g, '').split(' -> ').at(-1);
    return !(file.startsWith('docs/') || file.startsWith('tools/'));
  });
  if (bad.length) fail(`Unexpected changed paths:\n${bad.join('\n')}`);
  return status;
}

function prBody(status) {
  const d = state.data;
  return `## Task and change

Task: ITEM-106 owner actions left by PR #89: apply identification releases 62 and 63, publish the Workspace and hosted Centre, and observe a digest, reminder and bulk-failure e-mail.

Implementing agent: the owner, through the repository's ITEM-106 Termux orchestrator

Reviewing agent: GitHub CI and maintainer review

Changed behavior / affected surfaces: Records and generated governance documents only; no runtime or package change in this PR. ITEM-106 moves to ${status}. The flows:update reports, run inspections and owner observations are filed under docs/folio-Master-Flows-and-Endpoints/evidence. The config-build ledger records build ${d.build.version}.

## Evidence and handoff

Checks actually run and results: On Android Termux with Node ${process.version}: flows:update check before apply; releases 62 and 63 applied where required; final check UP_TO_DATE with exit 0. The ${GENERATORS.length} generators and ${CHECKS.length} targeted suites passed, and run-test-gate --check reported no undeclared omissions. Browser and full-gate coverage is provided by this PR's CI.

Generated outputs and their owning inputs (if applicable): flowreq, plan, disposition, outstanding, platform, flows:regenerate, docsite and docs:catalogue, generated from PRODUCTION_READINESS_REGISTER.json and the filed evidence.

Code/test evidence versus live evidence: Live evidence consists of the recorded tenant check/apply/readback reports, the successful sweep inspection, optional bulk inspection, the owner's five observed journeys, and both sites' BUILD-ID.json values matching build ${d.build.version} at commit ${d.build.commit.slice(0, 8)}. Code/test evidence consists of the targeted local checks and this PR's CI.

Remaining owner action or authorization: ${status === 'RESOLVED' ? 'None for ITEM-106; retain rollback backups briefly, then perform private-file cleanup.' : 'Correct or complete the failed live journeys recorded in the owner observations, then file a follow-up evidence revision before resolving ITEM-106.'}

<!-- No credentials, private configuration, tenant data, personal e-mail addresses, signed URLs or live endpoint values are included. -->
`;
}

async function stagePreflight() {
  heading('Preflight');
  if (!state.data.approved) {
    say('This automation can merge PRs, update five live Power Automate flows, upload two production sites, create an evidence commit, and merge its PR.');
    say('It never stores FTP passwords and it stops for Microsoft sign-in and real mailbox/browser observations.');
    const phrase = await ask('Type AUTOMATE ITEM-106 to approve those writes:');
    if (phrase !== 'AUTOMATE ITEM-106') fail('Approval phrase did not match.');
    state.data.approved = true;
    saveState();
  }
  const required = ['git', 'node', 'npm', 'gh', 'curl', 'zip', 'unzip', 'lftp', 'timeout', 'bash'];
  const missing = required.filter((x) => !commandExists(x));
  if (missing.length) fail(`Missing commands: ${missing.join(', ')}. Run START-AUTOMATION.sh again.`);
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 22) fail(`Node ${process.version} is too old; Node 22 or later is required.`);
  if (run('gh', ['auth', 'status'], { cwd: HOME, accept: [0, 1] }).status !== 0) {
    run('gh', ['auth', 'login'], { cwd: HOME });
  }
  run('gh', ['auth', 'setup-git'], { cwd: HOME });
  let gitName = capture('git', ['config', '--global', '--get', 'user.name'], { cwd: HOME, accept: [0, 1] }).stdout.trim();
  let gitEmail = capture('git', ['config', '--global', '--get', 'user.email'], { cwd: HOME, accept: [0, 1] }).stdout.trim();
  if (!gitName) {
    gitName = await ask('Git commit name:');
    git(['config', '--global', 'user.name', gitName], { cwd: HOME });
  }
  if (!gitEmail) {
    gitEmail = await ask('Git commit e-mail (GitHub no-reply recommended):', {
      validate: (v) => /^[^@\s]+@[^@\s]+$/.test(v) ? null : 'Enter a valid commit e-mail address.',
    });
    git(['config', '--global', 'user.email', gitEmail], { cwd: HOME });
  }
  if (commandExists('termux-wake-lock')) run('termux-wake-lock', [], { cwd: HOME, accept: [0, 1], quiet: true });
  advance('repository');
}

async function stageRepository() {
  heading('Repository and GitHub');
  if (!exists(path.join(REPO, '.git'))) {
    fs.mkdirSync(path.dirname(REPO), { recursive: true });
    run('git', ['clone', `https://github.com/${GH_REPO}.git`, REPO], { cwd: HOME });
  }
  const origin = capture('git', ['remote', 'get-url', 'origin'], { cwd: REPO }).stdout.trim();
  if (!origin.includes(GH_REPO)) fail(`${REPO} points to ${origin}, not ${GH_REPO}.`);
  ensureCleanRepo('Before repository automation');
  state.data.repository ||= {};
  if (!state.data.repository.pr89) {
    state.data.repository.pr89 = await ensurePrMerged(89);
    saveState();
  }
  if (!state.data.repository.pr90) {
    state.data.repository.pr90 = await ensurePrMerged(90);
    saveState();
  }
  git(['checkout', BASE_BRANCH], { cwd: REPO });
  git(['pull', '--ff-only'], { cwd: REPO });
  ensureCleanRepo('After pulling the merged default branch');
  const env = { ...process.env, PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: '1', PUPPETEER_SKIP_DOWNLOAD: '1' };
  npm(['ci', '--ignore-scripts'], { cwd: REPO, env });
  npm(['run', '-s', 'test:deeplinks'], { cwd: REPO, env });
  npm(['run', '-s', 'test:flowsupdate'], { cwd: REPO, env });
  const { item } = item106();
  if (!item || !['SPECIFIED_NOT_APPLIED', 'APPLIED_UNVERIFIED', 'RESOLVED'].includes(item.status)) {
    fail(`Unexpected ITEM-106 state: ${item?.status || 'missing'}`);
  }
  state.data.repository.head = capture('git', ['rev-parse', 'HEAD'], { cwd: REPO }).stdout.trim();
  saveState();
  advance('signin');
}

async function stageSignin() {
  heading('Microsoft tenant sign-in');
  const network = run('curl', ['-sS', '-o', '/dev/null', '-w', '%{http_code}', 'https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration'], {
    cwd: HOME,
    capture: true,
    accept: [0, 6, 28],
  });
  if (network.status !== 0 || network.stdout.trim() !== '200') {
    say('Microsoft sign-in does not resolve from this connection.');
    say('Move to the Android connection that can open microsoft.com/devicelogin, then run START-AUTOMATION.sh again.');
    return 'pause';
  }
  npm(['run', 'agent:access', '--', 'setup'], { cwd: REPO });
  let status = liveNpm(['run', 'agent:access', '--', 'status', '--live', '--resource', 'flow'], { cwd: REPO, accept: [0, 1] });
  if (status.status !== 0) {
    liveNpm(['run', 'agent:access', '--', 'signin', 'flow'], { cwd: REPO });
    status = liveNpm(['run', 'agent:access', '--', 'status', '--live', '--resource', 'flow'], { cwd: REPO, accept: [0, 1] });
  }
  if (status.status !== 0) fail('The Flow session did not verify after sign-in.');
  state.data.liveSince ||= utcDay();
  saveState();
  advance('flows');
}

async function stageFlows() {
  heading('Apply releases 62 and 63');
  const out = path.join(PRIVATE, 'flows');
  fs.mkdirSync(out, { recursive: true, mode: 0o700 });
  state.data.flowReports ||= [];
  for (const file of reportFiles(null, out)) {
    try {
      const report = parseJson(fs.readFileSync(file, 'utf8'), file);
      const allowed = report.kind === 'apply' ? ['APPLIED', 'UP_TO_DATE'] : ['UP_TO_DATE', 'WILL_UPDATE'];
      const relevant = flattenReport(file).filter((row) => ALL_FLOWS.includes(row.flowId));
      if (relevant.length && relevant.every((row) => allowed.includes(row.status))) {
        state.data.flowReports.push(file);
      }
    } catch { /* ignore incomplete or failed reports; the next check establishes live state */ }
  }
  state.data.flowReports = unique(state.data.flowReports);
  saveState();
  const before = new Set(reportFiles());
  const check = liveNpm(['run', '-s', 'flows:update', '--', 'check', '--only', FLOW_SELECTORS, '--out', out], {
    cwd: REPO,
    accept: [0, 1],
  });
  const initial = newestReport('check', before);
  const rows = validateReport(initial, ALL_FLOWS, ['UP_TO_DATE', 'WILL_UPDATE']);
  state.data.flowReports.push(initial);
  state.data.flowReports = unique(state.data.flowReports);
  saveState();
  const needs = new Set(rows.filter((x) => x.status === 'WILL_UPDATE').map((x) => x.flowId.toLowerCase()));
  if (check.status === 0 && needs.size) fail('flows:update exited 0 but reported WILL_UPDATE.');
  if (RELEASE_62.some((x) => needs.has(x.toLowerCase()))) {
    const prior = new Set(reportFiles());
    liveNpm(['run', '-s', 'flows:update', '--', 'apply', '--only', RELEASE_62.map((x) => x.slice(0, 8)).join(','), '--yes', '--out', out], { cwd: REPO });
    const applied = newestReport('apply', prior);
    validateReport(applied, RELEASE_62, ['APPLIED', 'UP_TO_DATE']);
    state.data.flowReports.push(applied);
    state.data.flowReports = unique(state.data.flowReports);
    saveState();
  }
  if (RELEASE_63.some((x) => needs.has(x.toLowerCase()))) {
    const prior = new Set(reportFiles());
    liveNpm(['run', '-s', 'flows:update', '--', 'apply', '--only', RELEASE_63.map((x) => x.slice(0, 8)).join(','), '--yes', '--out', out], { cwd: REPO });
    const applied = newestReport('apply', prior);
    validateReport(applied, RELEASE_63, ['APPLIED', 'UP_TO_DATE']);
    state.data.flowReports.push(applied);
    state.data.flowReports = unique(state.data.flowReports);
    saveState();
  }
  const finalBefore = new Set(reportFiles());
  liveNpm(['run', '-s', 'flows:update', '--', 'check', '--only', FLOW_SELECTORS, '--out', out], { cwd: REPO });
  const final = newestReport('check', finalBefore);
  validateReport(final, ALL_FLOWS, ['UP_TO_DATE']);
  state.data.flowReports.push(final);
  state.data.flowReports = unique(state.data.flowReports);
  state.data.da = utcDay();
  saveState();
  advance('build');
}

async function stageBuild() {
  heading('Build production packages');
  const out = path.join(PRIVATE, 'config-build');
  const ledgerRel = 'docs/folio-Master-Flows-and-Endpoints/registers/config-build-ledger.json';
  const ledgerFile = path.join(REPO, ledgerRel);
  const adopt = () => {
    if (!exists(out) || !exists(ledgerFile)) return null;
    try {
      const ledger = parseJson(fs.readFileSync(ledgerFile, 'utf8'), ledgerFile);
      const workspace = buildIdentity(path.join(out, 'workspace'));
      const centre = buildIdentity(path.join(out, 'centre'));
      const head = capture('git', ['rev-parse', 'HEAD'], { cwd: REPO }).stdout.trim();
      if (workspace.version !== ledger.version || centre.version !== ledger.version
          || workspace.commit !== ledger.commit || centre.commit !== ledger.commit
          || ledger.commit !== head) return null;
      return { ledger, workspace, centre };
    } catch { return null; }
  };
  let built = adopt();
  if (!built) {
    git(['checkout', BASE_BRANCH], { cwd: REPO });
    git(['pull', '--ff-only'], { cwd: REPO });
    ensureCleanRepo('Before config:rebuild');
    if (exists(out)) {
      const old = `${out}.incomplete-${Date.now()}`;
      fs.renameSync(out, old);
      say(`Moved an incomplete prior build to ${old}.`);
    }
    liveNpm(['run', '-s', 'config:rebuild', '--', '--out', out], { cwd: REPO });
    built = adopt();
    if (!built) fail('The config build did not produce identities matching its ledger.');
  } else {
    const status = repoStatus().split('\n').filter(Boolean);
    if (status.some((line) => !line.endsWith(` ${ledgerRel}`))) {
      fail(`A resumable build exists, but the repository has unrelated changes:\n${status.join('\n')}`);
    }
    say(`Adopting the already completed private build v${built.ledger.version}.`);
  }
  const { ledger, workspace, centre } = built;
  state.data.build = {
    ledger: ledgerRel,
    version: ledger.version,
    commit: ledger.commit,
    builtUtc: ledger.builtUtc,
    out,
    workspace,
    centre,
  };
  saveState();
  advance('publish');
}

async function stagePublish() {
  heading('Publish the Centre and Workspace');
  await publishSite('centre', 'hosted Centre', path.join(state.data.build.out, 'centre'), 'FOLIO-CENTRE');
  openUrl(CENTRE_BUILD_URL);
  await publishSite('workspace', 'Workspace', path.join(state.data.build.out, 'workspace'), 'FOLIO-WORKSPACE');
  openUrl(WORKSPACE_BUILD_URL);
  if (!(await yesNo('Do both browser BUILD-ID pages and the Workspace account menu show the expected build?', false))) {
    fail('Browser build verification was not confirmed.');
  }
  advance('day0');
}

async function stageDay0() {
  heading('Day 0 live setup');
  const p = watParts();
  const weekday = ['Sat', 'Sun'].includes(p.weekday) ? false : p.weekday !== 'Fri';
  const hour = Number(p.hour);
  if ((!weekday || hour < 9 || hour >= 17) && process.env.ITEM106_ALLOW_OUTSIDE_WINDOW !== '1') {
    say(`Current WAT time is ${p.weekday} ${p.hour}:00. Day 0 should run Monday-Thursday, 09:00-17:00 WAT.`);
    say('Run the automation again in that window. Set ITEM106_ALLOW_OUTSIDE_WINDOW=1 only if the owner deliberately accepts another schedule.');
    return 'pause';
  }
  openUrl(FLOW_CONFIG_URL);
  if (!(await yesNo('Have you privately noted NOTIFY_ENABLED, working hours, sweep recipients, ops recipient, and identity-map settings?', false))) {
    return 'pause';
  }
  say('The automation uses the conservative sweep choice: Day 1 Turn on -> Run -> Succeeded -> Turn off.');
  openUrl(WORKSPACE_URL);
  state.data.records ||= {};
  state.data.tasks ||= {};
  state.data.receipts ||= {};
  await remember(state.data.records, 'a', 'Create ZTEST-A, then paste its NITDA reference:', { validate: redactSafe });
  await remember(state.data.tasks, 'a', 'Assign task A to yourself, set its reminder for the next weekday, then paste its TASK reference:', {
    validate: (v) => /^TASK-(?:\d+|\d{4}-\d+)$/i.test(v) ? null : 'Expected TASK-<number> or TASK-YYYY-<number>.',
  });
  await remember(state.data.records, 'b', 'Create ZTEST-B and paste its NITDA reference:', { validate: redactSafe });
  await remember(state.data.tasks, 'b', 'Assign task B to yourself, acknowledge from its assignment link, then paste its TASK reference:', {
    validate: (v) => /^TASK-(?:\d+|\d{4}-\d+)$/i.test(v) ? null : 'Expected a TASK reference.',
  });
  await checkResult('assignee', 'Did a fresh private tab show task B acknowledged on the server?');
  await remember(state.data.records, 'c', 'Create ZTEST-C and paste its NITDA reference:', { validate: redactSafe });
  await remember(state.data.tasks, 'c', 'Assign task C to a colleague with yourself copied, then paste its TASK reference:', {
    validate: (v) => /^TASK-(?:\d+|\d{4}-\d+)$/i.test(v) ? null : 'Expected a TASK reference.',
  });
  await checkResult('other', "Did your copied link refuse acknowledgement because C belongs to someone else, leaving C awaiting receipt?");
  await remember(state.data.records, 'bulk', 'Create ZTEST-BULK, force the stale-form bulk failure, then paste its NITDA reference:', { validate: redactSafe });
  await checkResult('bulk', 'Did the bulk-failure e-mail arrive and open #/inbox rather than an acknowledgement page?');
  await remember(state.data.receipts, 'bulk', 'Paste the numeric Portal Outbox Receipt item ID for that bulk-failure message:', {
    validate: (v) => /^\d+$/.test(v) ? null : 'Enter the numeric SharePoint item ID only.',
  });
  state.data.d0 = utcDay();
  state.data.day1Expected = nextWeekday(watDay());
  saveState();
  advance('day1');
  say(`Day 0 is saved. Resume on ${state.data.day1Expected} between 09:00 and 17:00 WAT by running START-AUTOMATION.sh again.`);
  return 'pause';
}

async function stageDay1() {
  heading('Day 1 live observations');
  if (watDay() < state.data.day1Expected) {
    say(`Resume on or after ${state.data.day1Expected}; today is ${watDay()} WAT.`);
    return 'pause';
  }
  if (!state.data.d1) {
    state.data.d1 = utcDay();
    saveState();
  }
  openUrl(SWEEP_URL);
  if (!(await yesNo('Did you turn the sweep on, run it successfully, wait for Succeeded, then turn it off again?', false))) {
    return 'pause';
  }
  state.data.inspections ||= {};
  state.data.inspections.sweep ||= await inspectLatest(FLOW_IDS.sweep, state.data.d0, 'sweep', true);
  state.data.subjects ||= {};
  state.data.receipts ||= {};
  await checkResult('reminder', 'Did the reminder open task A without acknowledging it?');
  await remember(state.data.subjects, 'reminder', 'Enter the reminder subject (no e-mail address):', { validate: redactSafe });
  await remember(state.data.receipts, 'reminder', 'Enter its numeric Portal Outbox Receipt item ID:', {
    validate: (v) => /^\d+$/.test(v) ? null : 'Enter the numeric SharePoint item ID only.',
  });
  await checkResult('digestReference', 'Did task A in the digest open task A without acknowledging it?');
  await checkResult('digestAckList', 'Did the digest Acknowledge receipt link name task A only, not B or C?');
  await checkResult('digestTasks', 'Did Open my tasks open #/tasks?');
  await remember(state.data.subjects, 'digest', 'Enter the digest subject (no e-mail address):', { validate: redactSafe });
  await remember(state.data.receipts, 'digest', 'Enter its numeric Portal Outbox Receipt item ID:', {
    validate: (v) => /^\d+$/.test(v) ? null : 'Enter the numeric SharePoint item ID only.',
  });
  await checkResult('digestAcknowledge', 'After all checks, did the digest Acknowledge receipt button save task A successfully?');
  if (await yesNo('Inspect the latest BULK_OPS run automatically too?', true)) {
    state.data.inspections.bulk ||= await inspectLatest(FLOW_IDS.bulk, state.data.d0, 'bulk-failure', false);
  }
  if (!(await yesNo('Have you removed all ZTEST records, tasks, reminder, mirror and locator rows; retained receipts/audit; and restored configuration?', false))) {
    return 'pause';
  }
  state.data.cleanupDay = utcDay();
  saveState();
  advance('evidence');
}

async function stageEvidence() {
  heading('File evidence and update ITEM-106');
  const d = state.data;
  const ledger = path.join(REPO, d.build.ledger);
  const branch = 'owner/item106-evidence';
  const evidence = d.evidence ||= {};
  evidence.status ||= evidenceTargetStatus();
  evidence.branch ||= branch;
  saveState();
  if (['final', 'push', 'pr'].includes(evidenceResumePoint(evidence))) {
    await finishEvidencePr(evidence);
    return;
  }

  const current = capture('git', ['branch', '--show-current'], { cwd: REPO }).stdout.trim();
  if (current !== branch) {
    const initialStatus = repoStatus().split('\n').filter(Boolean);
    const unexpected = initialStatus.filter((line) => !line.endsWith(` ${d.build.ledger}`));
    if (unexpected.length) fail(`Unexpected changes before evidence branch:\n${unexpected.join('\n')}`);
    if (initialStatus.length && !evidence.stashApplied) {
      evidence.stashMessage ||= `item106-config-build-${Date.now()}`;
      saveState();
      if (!findStash(evidence.stashMessage)) {
        git(['stash', 'push', '-m', evidence.stashMessage, '--', d.build.ledger], { cwd: REPO });
      }
      evidence.stashCreated = true;
      saveState();
    }
    git(['checkout', BASE_BRANCH], { cwd: REPO });
    git(['pull', '--ff-only'], { cwd: REPO });
    const branchExists = capture('git', ['branch', '--list', branch], { cwd: REPO }).stdout.trim();
    if (branchExists) git(['checkout', branch], { cwd: REPO });
    else git(['checkout', '-b', branch], { cwd: REPO });
  }
  if (evidence.stashMessage && !evidence.stashApplied) {
    const stashRef = findStash(evidence.stashMessage);
    if (stashRef) {
      const pop = run('git', ['stash', 'pop', stashRef], { cwd: REPO, accept: [0, 1] });
      if (pop.status !== 0) {
        const unmerged = capture('git', ['diff', '--name-only', '--diff-filter=U'], { cwd: REPO }).stdout.trim().split('\n').filter(Boolean);
        if (unmerged.length === 1 && unmerged[0] === d.build.ledger) {
          git(['checkout', '--theirs', '--', d.build.ledger], { cwd: REPO });
          git(['reset', '-q'], { cwd: REPO });
          const retained = findStash(evidence.stashMessage);
          if (retained) git(['stash', 'drop', retained], { cwd: REPO });
        } else {
          fail(`stash pop conflicts need review: ${unmerged.join(', ')}`);
        }
      }
    }
    evidence.stashApplied = true;
    saveState();
  }
  if (!exists(ledger)) fail(`Missing build ledger ${ledger}.`);

  if (!evidence.commit && evidence.helperApplied && !repoStatus()) {
    const expectedSubject = `ITEM-106: owner evidence for releases 62 and 63 and build ${d.build.version}`;
    const subject = capture('git', ['log', '-1', '--pretty=%s'], { cwd: REPO }).stdout.trim();
    if (subject === expectedSubject) {
      evidence.commit = capture('git', ['rev-parse', 'HEAD'], { cwd: REPO }).stdout.trim();
      saveState();
    }
  }

  if (!evidence.commit) {
    const evidenceRefs = unique(d.flowReports.map(recordReport));
    const evDir = path.join(REPO, 'docs/folio-Master-Flows-and-Endpoints/evidence');
    const inspectionRefs = [];
    for (const inspection of Object.values(d.inspections || {})) {
      if (!inspection?.file) continue;
      const target = path.join(evDir, path.basename(inspection.file));
      fs.copyFileSync(inspection.file, target);
      inspectionRefs.push(relativeRepo(target));
    }
    const observations = observationJson();
    const obsFile = path.join(evDir, `${d.d1}-item106-owner-observations.json`);
    fs.writeFileSync(obsFile, `${JSON.stringify(observations, null, 2)}\n`);
    run('node', [path.join(BUNDLE, 'scripts', 'obscheck.mjs'), obsFile], { cwd: REPO, accept: evidence.status === 'RESOLVED' ? [0] : [0, 1] });
    const pairs = [];
    for (const ref of evidenceRefs) {
      const what = ref.includes('-flows-check')
        ? 'flows:update check: live state of the release 62 and 63 flows when read'
        : 'flows:update apply: release 62 or 63 packages written and read back';
      pairs.push(`${ref}::${what}`);
    }
    for (const ref of inspectionRefs) pairs.push(`${ref}::flows:inspect of the run that sent the ITEM-106 test e-mails`);
    pairs.push(`${relativeRepo(obsFile)}::the owner's observations of the five e-mail and link journeys`);
    pairs.push(`${d.build.ledger}::build ${d.build.version}: the Workspace and Centre published from one commit`);
    const status = evidence.status;
    const refs = pairs.map((x) => x.split('::')[0]);
    evidence.refs = refs;
    evidence.pairs = pairs;
    evidence.observationFile = relativeRepo(obsFile);
    saveState();
    if (!evidence.helperApplied) {
      if (!helperAlreadyApplied(status, refs)) {
        run('node', [
          path.join(BUNDLE, 'scripts', 'item106.mjs'),
          status,
          evidenceWhyOpen(status),
          evidenceNote(status),
          ...pairs,
        ], { cwd: REPO });
      }
      evidence.helperApplied = true;
      saveState();
    }
    if (!evidence.generatorsPassed) {
      runGeneratorsAndChecks();
      evidence.generatorsPassed = true;
      saveState();
    }
    const changed = validateChangedPaths();
    if (!changed.length) fail('No evidence changes were produced.');
    git(['add', '-A', 'docs', 'tools'], { cwd: REPO });
    const unstaged = capture('git', ['status', '--porcelain'], { cwd: REPO }).stdout.trim().split('\n').filter((x) => x && x[1] !== ' ');
    if (unstaged.length) fail(`Not every expected change is staged:\n${unstaged.join('\n')}`);
    git([
      'commit',
      '-m', `ITEM-106: owner evidence for releases 62 and 63 and build ${d.build.version}`,
      '-m', `Record live apply/readback, host publication, run inspections and owner observations; move ITEM-106 to ${status} and regenerate governed outputs.\n\nCo-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>`,
    ], { cwd: REPO });
    evidence.commit = capture('git', ['rev-parse', 'HEAD'], { cwd: REPO }).stdout.trim();
    saveState();
  }

  if (!evidence.pushed) {
    git(['push', '-u', 'origin', branch], { cwd: REPO });
    evidence.pushed = true;
    saveState();
  }
  const bodyFile = path.join(PRIVATE, 'evidence-pr-body.md');
  fs.writeFileSync(bodyFile, prBody(evidence.status), { mode: 0o600 });
  let pr;
  const existing = ghJson([
    'pr', 'list', '-R', GH_REPO, '--head', branch, '--state', 'all', '--limit', '20',
    '--json', 'number,url,headRefOid,state',
  ]).find((candidate) => candidate.headRefOid === evidence.commit && ['OPEN', 'MERGED'].includes(candidate.state));
  if (existing) pr = existing;
  else {
    const created = capture('gh', [
      'pr', 'create', '-R', GH_REPO, '--base', BASE_BRANCH, '--head', branch,
      '--title', `ITEM-106: owner evidence (releases 62 and 63, build ${d.build.version})`,
      '--body-file', bodyFile,
    ], { cwd: REPO }).stdout.trim();
    pr = { number: Number(created.split('/').at(-1)), url: created };
  }
  evidence.pr = pr.number;
  evidence.url = pr.url;
  saveState();
  await finishEvidencePr(evidence);
}

async function stageFinal() {
  heading('Final operational verification');
  git(['checkout', BASE_BRANCH], { cwd: REPO });
  git(['pull', '--ff-only'], { cwd: REPO });
  const { item } = item106();
  if (item.status !== state.data.evidence.status) fail(`ITEM-106 is ${item.status}, expected ${state.data.evidence.status}.`);
  const out = path.join(PRIVATE, 'final-flow-check');
  fs.mkdirSync(out, { recursive: true, mode: 0o700 });
  const before = new Set(reportFiles('check', out));
  liveNpm(['run', '-s', 'flows:update', '--', 'check', '--only', FLOW_SELECTORS, '--out', out], { cwd: REPO });
  const finalReport = newestReport('check', before, out);
  validateReport(finalReport, ALL_FLOWS, ['UP_TO_DATE']);
  liveNpm(['run', '-s', 'config:drift'], { cwd: REPO });
  await verifyRemoteSite('centre', 'hosted Centre', 'FOLIO-CENTRE');
  await verifyRemoteSite('workspace', 'Workspace', 'FOLIO-WORKSPACE');
  openUrl(CENTRE_BUILD_URL);
  openUrl(WORKSPACE_BUILD_URL);
  if (!(await yesNo('Are the sweep/configuration/test-data state and both browser BUILD-ID pages correct?', false))) {
    fail('Final browser/operational verification was not confirmed.');
  }
  for (const target of [state.data.build.out, path.join(PRIVATE, 'final-flow-check')]) {
    if (target && exists(target)) fs.rmSync(target, { recursive: true, force: true });
  }
  if (await yesNo('Delete the saved local Flow session now?', true)) {
    liveNpm(['run', 'agent:access', '--', 'signout', 'flow'], { cwd: REPO, accept: [0, 1] });
  }
  if (commandExists('termux-wake-unlock')) run('termux-wake-unlock', [], { cwd: HOME, accept: [0, 1], quiet: true });
  state.data.finishedUtc = stamp();
  saveState();
  advance('done');
  say('ITEM-106 automation is complete. Keep the private Flow and FTP site backups for about one week, then run:');
  say(`  rm -rf ${shellQuote(path.join(PRIVATE, 'flows'))} ${shellQuote(path.join(PRIVATE, 'site-backup'))}`);
}

function printStatus() {
  console.log(JSON.stringify({
    stage: state.stage,
    completed: state.completed,
    updatedUtc: state.updatedUtc,
    repo: state.repo,
    build: state.data.build ? {
      version: state.data.build.version,
      commit: state.data.build.commit,
    } : null,
    evidence: state.data.evidence || null,
  }, null, 2));
}

function selfTest() {
  if (CI_ROUNDS < 14) fail('CI round bound is too short');
  if (CHECK_TIMEOUT < 900) fail('targeted-check timeout is too short');
  if (parsePrChecks({ stdout: '', stderr: 'no checks reported on the branch' }, 90).length !== 0) {
    fail('no-check race self-test failed');
  }
  const resumeCases = [
    [{ helperApplied: true }, 'files'],
    [{ commit: 'abc' }, 'publish'],
    [{ pr: 91 }, 'pr'],
    [{ pr: 91, mergeCommit: 'def' }, 'push'],
    [{ pr: 91, mergeCommit: 'def', pushRunPassed: true }, 'final'],
  ];
  for (const [checkpoint, expected] of resumeCases) {
    if (evidenceResumePoint(checkpoint) !== expected) fail(`evidence resume self-test failed at ${expected}`);
  }
  const tls = ftpTlsCommands(false, path.join(PRIVATE, 'missing-ca.pem'));
  for (const required of ['ftp:ssl-force true', 'ftp:ssl-protect-data true', 'ftp:ssl-protect-list true']) {
    if (!tls.includes(required)) fail(`FTP TLS self-test failed: ${required}`);
  }
  const sample = {
    schema: 'folio-flows-update-report/v1',
    kind: 'check',
    flows: ALL_FLOWS.map((flowId) => ({ flowId, flow: flowId.slice(0, 8), packages: [{ status: 'UP_TO_DATE' }] })),
  };
  const temp = path.join(PRIVATE, `self-test-${process.pid}.json`);
  fs.writeFileSync(temp, JSON.stringify(sample));
  validateReport(temp, ALL_FLOWS, ['UP_TO_DATE']);
  fs.rmSync(temp);
  const reportDir = path.join(PRIVATE, `self-test-reports-${process.pid}`);
  fs.mkdirSync(reportDir);
  const oldReport = path.join(reportDir, 'flows-check-old.json');
  fs.writeFileSync(oldReport, '{}');
  let staleRejected = false;
  try { newestReport('check', new Set([oldReport]), reportDir); } catch { staleRejected = true; }
  if (!staleRejected) fail('stale report self-test failed');
  const newReport = path.join(reportDir, 'flows-check-new.json');
  fs.writeFileSync(newReport, '{}');
  if (newestReport('check', new Set([oldReport]), reportDir) !== newReport) fail('fresh report self-test failed');
  fs.rmSync(reportDir, { recursive: true });

  const envFile = path.join(PRIVATE, `self-test-env-${process.pid}.sh`);
  fs.writeFileSync(envFile, 'printf "ITEM106_TEST_SECRET\\n" >&2\nexit 7\n', { mode: 0o600 });
  let envError = '';
  try { loadEnvironmentFile(envFile, PRIVATE); } catch (error) { envError = error.message; }
  fs.rmSync(envFile);
  if (!envError.includes('bash exited 7') || envError.includes('ITEM106_TEST_SECRET')) {
    fail('environment redaction self-test failed');
  }

  const stashRepo = path.join(PRIVATE, `self-test-stash-${process.pid}`);
  fs.mkdirSync(stashRepo);
  git(['init', '-q'], { cwd: stashRepo });
  git(['config', 'user.name', 'ITEM-106 self-test'], { cwd: stashRepo });
  git(['config', 'user.email', 'item106-self-test@example.invalid'], { cwd: stashRepo });
  const stashFile = path.join(stashRepo, 'ledger.txt');
  fs.writeFileSync(stashFile, 'base\n');
  git(['add', 'ledger.txt'], { cwd: stashRepo });
  git(['commit', '-q', '-m', 'base'], { cwd: stashRepo });
  fs.writeFileSync(stashFile, 'other\n');
  git(['stash', 'push', '-q', '-m', 'unrelated-stash'], { cwd: stashRepo });
  fs.writeFileSync(stashFile, 'target\n');
  git(['stash', 'push', '-q', '-m', 'item106-exact-stash'], { cwd: stashRepo });
  fs.writeFileSync(stashFile, 'newest\n');
  git(['stash', 'push', '-q', '-m', 'newer-unrelated-stash'], { cwd: stashRepo });
  const exactStash = findStash('item106-exact-stash', stashRepo);
  if (!exactStash || exactStash === 'stash@{0}') fail('exact stash self-test failed');
  git(['stash', 'drop', '-q', exactStash], { cwd: stashRepo });
  if (findStash('item106-exact-stash', stashRepo) || !findStash('newer-unrelated-stash', stashRepo)) {
    fail('named stash drop self-test failed');
  }
  fs.rmSync(stashRepo, { recursive: true });

  if (nextWeekday('2026-11-06') !== '2026-11-09') fail('nextWeekday self-test failed');
  if (!validateFtpUser('if0_test') && !validateRemoteDir('/htdocs')) {
    say('Self-test passed.');
    return;
  }
  fail('validation self-test failed');
}

const handlers = {
  preflight: stagePreflight,
  repository: stageRepository,
  signin: stageSignin,
  flows: stageFlows,
  build: stageBuild,
  publish: stagePublish,
  day0: stageDay0,
  day1: stageDay1,
  evidence: stageEvidence,
  final: stageFinal,
};

async function main() {
  const command = process.argv[2] || 'run';
  if (command === 'status') return printStatus();
  if (command === 'self-test') return selfTest();
  if (command === 'reset') {
    if (!process.argv.includes('--yes')) fail('reset requires --yes; it removes only the resumable state, not backups.');
    fs.rmSync(STATE_FILE, { force: true });
    say('Automation state reset. Private backups were retained.');
    return;
  }
  if (command === 'help' || command === '--help' || command === '-h') {
    console.log(`Usage:
  node item106-auto.mjs run        run or resume
  node item106-auto.mjs status     show the current checkpoint
  node item106-auto.mjs self-test  test local parsing and safety guards
  node item106-auto.mjs reset --yes

State: ${STATE_FILE}
Private files: ${PRIVATE}
Repository: ${REPO}`);
    return;
  }
  if (command !== 'run' && command !== 'resume') fail(`Unknown command: ${command}`);
  while (state.stage !== 'done') {
    const handler = handlers[state.stage];
    if (!handler) fail(`No handler for stage ${state.stage}`);
    const result = await handler();
    if (result === 'pause') {
      saveState();
      say(`\nPaused safely at stage "${state.stage}". Run START-AUTOMATION.sh again to resume.`);
      return;
    }
  }
  say('Automation is already complete.');
}

main().catch((error) => {
  state.lastError = { at: stamp(), stage: state.stage, message: error.message };
  try { saveState(); } catch { /* preserve original failure */ }
  console.error(`\nSTOPPED SAFELY at stage "${state.stage}":\n${error.message}`);
  console.error('\nFix the stated issue, then run START-AUTOMATION.sh again. No completed stage will be repeated.');
  process.exitCode = 1;
});
