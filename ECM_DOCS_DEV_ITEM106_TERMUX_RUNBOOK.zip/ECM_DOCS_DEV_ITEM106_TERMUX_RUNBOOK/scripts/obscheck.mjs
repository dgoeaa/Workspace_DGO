// node ~/obscheck.mjs <observations.json>  — exits 1 and lists what to fix
import fs from 'node:fs';
const file = process.argv[2];
const text = fs.readFileSync(file, 'utf8');
const o = JSON.parse(text);
const bad = [];
for (const l of text.split('\n')) if (l.includes('REPLACE')) bad.push(`fill in: ${l.trim()}`);
if (/[\w.+-]+@[\w-]+\.[a-z][\w.-]*/i.test(text)) bad.push('remove the e-mail address(es)');
if (/[?&](sig|sp|sv)=/i.test(text)) bad.push('remove signed-URL parameters (sig/sp/sv)');
if (/safelinks|url=https?%3a/i.test(text)) bad.push('decode the Safe Links wrapper first');
if (o.schema !== 'folio-owner-observations/v1' || o.item !== 'ITEM-106') bad.push('wrong schema or item');
const obs = Array.isArray(o.observations) ? o.observations : [];
for (const j of ['bulk-failure', 'assignment-link-assignee', 'assignment-link-other-person', 'digest', 'reminder'])
  if (!obs.some((x) => x.journey === j)) bad.push(`missing journey ${j}`);
for (const x of obs) if (x.pass !== true) bad.push(`${x.journey}: set "pass": true only if it behaved as described`);
if (bad.length) { console.error(bad.map((b) => `- ${b}`).join('\n')); process.exit(1); }
console.log(`Observations OK: ${obs.length} journeys, all passed.`);
