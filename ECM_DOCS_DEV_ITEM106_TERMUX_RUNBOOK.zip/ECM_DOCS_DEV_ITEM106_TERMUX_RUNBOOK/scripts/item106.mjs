// Run from the repo root, after PR 89 is merged and pulled:
//   node ~/item106.mjs <STATUS> "<whyOpen>" "<revision note>" "<file>::<what it shows>" ...
// Sets ITEM-106's status, whyOpen and evidence; marks S2 (and S3 when RESOLVED) done today;
// bumps registerVersion, compiledUtc (today) and compiledAgainstCommit (HEAD); appends a revision
// note; moves the "Current owning pin" paragraphs of release-reference.md and known-gaps.md; and
// re-pins their reviewed digests in docs/governance/DOC_MIGRATION_MAP.json.
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const [status, whyOpen, note, ...pairs] = process.argv.slice(2);
const REG = 'docs/deployment/PRODUCTION_READINESS_REGISTER.json';
const PINS = ['docs/governance/release-reference.md', 'docs/governance/known-gaps.md'];
const r = JSON.parse(fs.readFileSync(REG, 'utf8'));
if (!r.statusVocabulary?.[status]) throw new Error(`Unknown status ${status}; use one of ${Object.keys(r.statusVocabulary).join(', ')}`);
if (!whyOpen || !note || note.length < 40) throw new Error('Give a whyOpen text and a revision note of at least 40 characters.');
if (/\b\d{1,4} of \d{1,4}\b/.test(whyOpen)) throw new Error('Avoid "N of M" counts in whyOpen: the readiness gate needs each one stated in a non-derived file.');
const it = r.items.find((x) => x.id === 'ITEM-106');
if (!it) throw new Error('ITEM-106 is not in the register: merge PR 89 and pull first.');
const today = new Date().toISOString().slice(0, 10);
for (const p of pairs) {
  const [ref, states] = p.split('::');
  if (!fs.existsSync(ref)) throw new Error(`No such file: ${ref}`);
  if (!states) throw new Error(`Say what ${ref} shows: "${ref}::<what it shows>"`);
  if (!it.evidence.some((e) => e.ref === ref)) it.evidence.push({ type: 'file', ref, states });
}
it.status = status;
it.whyOpen = whyOpen;
it.steps = it.steps.map((s) => s
  .replace(/^S2 \(owner\)/, `S2 (done ${today})`)
  .replace(/^S3 \(owner\)/, status === 'RESOLVED' ? `S3 (done ${today})` : 'S3 (owner)'));
const prior = { v: String(r.registerVersion), utc: String(r.compiledUtc), commit: String(r.compiledAgainstCommit) };
const [a, b, c] = prior.v.split('.').map(Number);
r.registerVersion = `${a}.${b}.${c + 1}`;
r.compiledUtc = today;
r.compiledAgainstCommit = execFileSync('git', ['rev-parse', 'HEAD']).toString().trim();
r.revisionNotes.push({ version: r.registerVersion, utc: today, note });
const past = { adds: 'added', records: 'recorded', moves: 'moved' };
const basis = status === 'RESOLVED' ? 'apply and observation evidence' : 'apply evidence';
const pins = PINS.map((pf) => {
  const t = fs.readFileSync(pf, 'utf8');
  const m = t.match(/\*\*Current owning pin:\*\*[\s\S]*?\n\n/);
  if (!m) throw new Error(`${pf}: no "Current owning pin" paragraph`);
  let p = m[0];
  for (const [from, to] of [[`**${prior.v}**`, `**${r.registerVersion}**`], [`**${prior.utc}**`, `**${r.compiledUtc}**`],
    [`**\`${prior.commit}\`**`, `**\`${r.compiledAgainstCommit}\`**`]]) {
    if (!p.includes(from)) throw new Error(`${pf}: the pin paragraph does not show ${from}`);
    p = p.replace(from, to);
  }
  const lead = `. This revision moves ITEM-106 to \`${status}\` on the owner's ${basis} of ${today}.`;
  const was = `${prior.v} (\`${prior.commit.slice(0, 8)}\`)`;
  const known = /\.\s+This\s+revision\s+(adds|records|moves)\b/;
  const other = /\.\s+This\s+((?:[\w-]+\s+)?)revision\s+/;
  const anchor = `**\`${r.compiledAgainstCommit}\`**.`;
  if (known.test(p)) p = p.replace(known, (_, verb) => `${lead} Revision ${was} ${past[verb]}`);
  else if (other.test(p)) p = p.replace(other, (_, adj) => `${lead} The prior ${adj.replace(/\s+/g, ' ')}revision ${was} `);
  else if (p.includes(anchor)) p = p.replace(anchor, `${anchor.slice(0, -1)}${lead} What follows describes revision ${was} and earlier.`);
  else throw new Error(`${pf}: cannot place the revision sentence in the pin paragraph`);
  return [pf, t.replace(m[0], p)];
});
const MAP = 'docs/governance/DOC_MIGRATION_MAP.json';
const map = JSON.parse(fs.readFileSync(MAP, 'utf8'));
const digest = (t) => createHash('sha256').update(t).digest('hex');
const section = (md, heading) => {
  const at = md.indexOf(`${heading}\n`); const next = md.indexOf('\n## ', at + heading.length + 1);
  return md.slice(at, next < 0 ? md.length : next + 1);
};
for (const [pf, t] of pins) {
  const review = (map.sectionReconciliations[pf] || []).find((x) => section(t, x.heading).includes('**Current owning pin:**'));
  if (!review || !map.contentReviews[pf]) throw new Error(`${MAP}: no reviewed section holds the pin of ${pf}`);
  review.reviewedSha256 = digest(section(t, review.heading));
  review[`item106${status === 'RESOLVED' ? 'Resolution' : 'Apply'}Review`] = `${today}: update only the current-pin paragraph to readiness `
    + `${r.registerVersion} at ${r.compiledAgainstCommit} after ITEM-106 moved to ${status} on the owner's ${basis}. `
    + `The ${prior.v} wording is retained as the prior revision; all other statuses, baselines and review records are unchanged.`;
  map.contentReviews[pf] = digest(t);
}
fs.writeFileSync(REG, JSON.stringify(r, null, 2) + '\n');
for (const [pf, t] of pins) fs.writeFileSync(pf, t);
fs.writeFileSync(MAP, JSON.stringify(map, null, 2) + '\n');
console.log(`ITEM-106 is now ${status} (${it.evidence.length} evidence entries); register ${r.registerVersion}, `
  + `compiled ${r.compiledUtc} against ${r.compiledAgainstCommit.slice(0, 8)}; pins moved in ${PINS.join(' and ')}.`);
