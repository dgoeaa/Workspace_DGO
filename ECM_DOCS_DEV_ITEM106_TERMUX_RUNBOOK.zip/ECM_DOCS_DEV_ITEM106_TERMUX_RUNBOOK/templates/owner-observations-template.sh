cat > "$OBS" <<EOF
{
  "schema": "folio-owner-observations/v1",
  "item": "ITEM-106",
  "observedBy": "Registry owner (signed in as themself); a colleague for task C",
  "days": { "setUp": "$D0", "observed": "$D1" },
  "builds": {
    "ledger": "$LEDGER",
    "workspace": { "host": "folio-platform.page.gd", "version": "$VER", "commit": "$COMMIT" },
    "centre": { "host": "folio-cac.page.gd", "version": "$VER", "commit": "$COMMIT" }
  },
  "flows": "Releases 62 and 63 applied with flows:update and read back UP_TO_DATE; the check and apply reports are filed beside this file.",
  "observations": [
    { "journey": "bulk-failure", "record": "REPLACE (ZTEST-BULK)",
      "subject": "Bulk assignment: 1 of 1 not completed",
      "outboxReceipt": "bulk-failure receipt REPLACE",
      "link": "index.html#/inbox",
      "result": "The email arrived; its button opened the Inbox, not an acknowledgement page.",
      "pass": "REPLACE" },
    { "journey": "assignment-link-assignee", "task": "REPLACE (task B)",
      "result": "The assignee's own assignment link acknowledged task B; a fresh private tab showed it acknowledged.",
      "pass": "REPLACE" },
    { "journey": "assignment-link-other-person", "task": "REPLACE (task C)",
      "result": "The copied owner opened task C's link and saw 'Not acknowledged: ... is assigned to someone else'; C stayed awaiting receipt.",
      "pass": "REPLACE" },
    { "journey": "digest", "subject": "Folio: REPLACE task(s) need your attention",
      "outboxReceipt": "task-digest receipt REPLACE",
      "checks": {
        "referenceLinkA": "Task A's reference opened task A (intent=open, source=digest); A stayed awaiting receipt.",
        "acknowledgeButton": "The Acknowledge receipt link listed task A only (not B or C).",
        "openMyTasks": "Open my tasks opened the task list (#/tasks)."
      },
      "pass": "REPLACE" },
    { "journey": "reminder", "subject": "Reminder: REPLACE",
      "outboxReceipt": "task-reminder receipt REPLACE",
      "link": "index.html?ref=REPLACE&intent=open&source=reminder",
      "result": "The reminder opened task A; A stayed awaiting receipt; nothing was acknowledged.",
      "pass": "REPLACE" }
  ],
  "runs": {
    "sweep": "AUTO_SCHEDULED_SWEEP run REPLACE on $D1: Succeeded (inspection filed beside this file).",
    "bulk": "BULK_OPS_DATA_RETRIEVAL_HTTP run on $D0: REPLACE (run ID and inspection file, or: not inspected)."
  },
  "cleanup": "ZTEST records REPLACE and their tasks, reminder, mirror and locator rows removed on REPLACE; Outbox receipts and audit rows kept; counter gaps accepted (offset, no reset), as in MANUAL-2.",
  "redaction": "No e-mail addresses, signed URLs or Safe Links wrappers recorded: references, run IDs and Outbox receipt IDs only."
}
EOF
