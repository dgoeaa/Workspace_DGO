ECM_DOCS_DEV ITEM-106 TERMUX RUNBOOK
====================================

This bundle is designed for Android + Termux.

FILES
-----
1. ITEM-106-Termux-Operational-Runbook.pdf
   Best for reading or printing.

2. ITEM-106-Termux-Operational-Runbook.html
   Best for reading offline on a phone and copying commands.

3. ITEM-106-Termux-Operational-Runbook.md
   Editable source version.

4. scripts/item106-auto.mjs
   Main resumable automation state machine.

5. scripts/item106.mjs
   Updates ITEM-106 and its governance pins after evidence is filed.

6. scripts/obscheck.mjs
   Checks the owner-observations JSON before it is committed.

7. templates/owner-observations-template.sh
   Creates the owner-observations JSON template.

8. templates/pr-body-template.md
   Editable pull-request description for the evidence PR.

9. QUICK-CHECKLIST.txt
   Short phone-friendly progress tracker and fallback checklist.

10. START-AUTOMATION.sh
   Recommended: one-command resumable Termux automation.

11. AUTOMATION-README.txt
    What is automated, what still requires you, and how to resume.

INSTALL IN TERMUX
------------------
1. Install unzip and allow access to Android Downloads:

   pkg install -y unzip
   termux-setup-storage

2. Find the downloaded ZIP in:

   ~/storage/downloads/

3. Extract it into your Termux home:

   cd ~
   unzip ~/storage/downloads/ECM_DOCS_DEV_ITEM106_TERMUX_RUNBOOK.zip

4. Set the bundle location:

   export BUNDLE=~/ECM_DOCS_DEV_ITEM106_TERMUX_RUNBOOK

5. Open the HTML guide:

   termux-open "$BUNDLE/ITEM-106-Termux-Operational-Runbook.html"

Or open the PDF from Android's Files app.

EASIEST METHOD
--------------
Instead of following the long guide manually, run:

   bash ~/storage/downloads/ECM_DOCS_DEV_ITEM106_TERMUX_RUNBOOK/START-AUTOMATION.sh

The automation resumes after interruptions. It pauses only for Microsoft
device sign-in, FTP passwords, and the real browser/e-mail observations that
cannot safely be performed by a script.

CURRENT REPOSITORY STATUS
-------------------------
At the time this bundle was produced:

- PR #89 was green, merged, and its default-branch push run passed.
- PR #90 was then green, merged, and its default-branch push run passed.
- Nothing was applied to the live tenant or FTP sites while preparing the
  bundle. The automation verifies the repository state again before proceeding.

SECURITY
--------
Never put passwords, Microsoft device codes, signed flow URLs, e-mail addresses,
Safe Links wrappers, or tenant data in Git, a PR, or the evidence files.
